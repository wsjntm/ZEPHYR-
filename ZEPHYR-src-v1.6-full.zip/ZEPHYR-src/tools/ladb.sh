#!/system/bin/sh
# 本地 adb 包装器：用打包的 bionic adb（经 linker64 载入）执行命令
# 用法: sh tools/ladb.sh version | devices | pair 127.0.0.1:PORT CODE | connect 127.0.0.1:PORT | install -r xxx.apk
W="/data/data/com.milkcode/files/terminal-user/workspace/2026-11-01/你重新帮我做一个吧，这个是在电脑上运行adb的给"
export HOME="$W/work/adbhome"
export LD_LIBRARY_PATH="$W/work/alibs"
ADB="/system/bin/linker64 $W/work/alibs/libadb.so"

# 确保服务端在 127.0.0.1:5037（fork-server 不可用时走 nodaemon）
if ! (echo > /dev/tcp/127.0.0.1/5037) 2>/dev/null; then
    nohup $ADB -L tcp:5037 nodaemon server > "$W/work/adb_server.log" 2>&1 &
    sleep 3
fi

exec $ADB "$@"
