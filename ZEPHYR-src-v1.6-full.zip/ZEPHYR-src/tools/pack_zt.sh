#!/bin/sh
# 把四个载荷打成单文件自解压包 app/assets/zt_all
set -e
cd "$(dirname "$0")/.."
A=app/assets
OUT=$A/zt_all
FILES="zt_run zt_su zt_fanout.zte zt_su.zte"

SPEC=""
TOTAL=0
for f in $FILES; do
  SZ=$(stat -c %s "$A/$f")
  H=$(sha256sum "$A/$f" | cut -d' ' -f1)
  SPEC="$SPEC $f:$SZ:$H"
  TOTAL=$((TOTAL+SZ))
done

{
  echo '#!/system/bin/sh'
  echo '# ZT 单文件自解压包 —— 解包到当前目录后由外部脚本启动'
  echo "ZT_SPEC=\"$SPEC\""
  echo "ZT_TOTAL=$TOTAL"
  echo 'SELF=$0'
  echo 'LN=$(awk "/^###ZT_BLOB###\$/{print NR; exit}" "$SELF")'
  echo 'HDR=$(head -n "$LN" "$SELF" | wc -c)'
  echo 'BLOB=$((HDR + 1))'
  echo 'OFF=0'
  echo 'for it in $ZT_SPEC; do'
  echo '  N=$(echo "$it" | cut -d: -f1)'
  echo '  S=$(echo "$it" | cut -d: -f2)'
  echo '  H=$(echo "$it" | cut -d: -f3)'
  echo '  tail -c +$((BLOB + OFF)) "$SELF" | head -c "$S" > "$N"'
  echo '  A=$(sha256sum "$N" | cut -d" " -f1)'
  echo '  if [ "$A" != "$H" ]; then echo "ZT_BAD=$N"; exit 3; fi'
  echo '  echo "ZT_OK=$N:$S"'
  echo '  OFF=$((OFF + S))'
  echo 'done'
  echo 'chmod 755 zt_run zt_su 2>/dev/null'
  echo 'chmod 644 zt_fanout.zte zt_su.zte 2>/dev/null'
  echo 'echo ZT_UNPACK_DONE'
  echo 'exit 0'
  echo '###ZT_BLOB###'
  for f in $FILES; do cat "$A/$f"; done
} > "$OUT"

chmod 755 "$OUT"
echo "built $OUT  $(stat -c %s "$OUT") bytes"
