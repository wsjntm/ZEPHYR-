import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageOutputStream;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.Iterator;

/** 把 icon-src.jpg 转成各密度 mipmap PNG。 */
public class IconGen {
    static BufferedImage load(String p) throws Exception {
        BufferedImage src = ImageIO.read(new File(p));
        if (src == null) throw new RuntimeException("无法解码: " + p);
        return src;
    }

    static BufferedImage scale(BufferedImage src, int size) {
        BufferedImage out = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = out.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        // 居中裁成正方形再缩放
        int w = src.getWidth(), h = src.getHeight();
        int side = Math.min(w, h);
        int x = (w - side) / 2, y = (h - side) / 2;
        g.drawImage(src, 0, 0, size, size, x, y, x + side, y + side, null);
        g.dispose();
        return out;
    }

    public static void main(String[] a) throws Exception {
        String srcPath = a[0];
        String resDir = a[1];
        BufferedImage src = load(srcPath);
        String[] dirs = {"mipmap-mdpi", "mipmap-hdpi", "mipmap-xhdpi", "mipmap-xxhdpi", "mipmap-xxxhdpi"};
        int[] sizes = {48, 72, 96, 144, 192};
        for (int i = 0; i < dirs.length; i++) {
            File d = new File(resDir, dirs[i]);
            d.mkdirs();
            BufferedImage img = scale(src, sizes[i]);
            File out = new File(d, "ic_launcher.png");
            ImageIO.write(img, "png", out);
            System.out.println(out + " " + img.getWidth() + "x" + img.getHeight() + " " + out.length() + "B");
        }
        // 自适应图标用的 432px 背景（108dp @ xxxhdpi）
        File d = new File(resDir, "mipmap-xxxhdpi");
        BufferedImage bg = scale(src, 432);
        File out = new File(d, "ic_launcher_bg.png");
        ImageIO.write(bg, "png", out);
        System.out.println(out + " 432x432 " + out.length() + "B");
    }
}
