#!/bin/sh
# 构建 APK（无 Gradle，全命令行）
set -e
APP=$(cd "$(dirname "$0")/.." && pwd)/app
SDK=${SDK:-/workspace/work/sdk}
AJAR=$SDK/android.jar
R8=${R8:-/workspace/work/dl/r8.jar}
BUILD=$APP/build
OUT=$APP/out
KS=$APP/keystore.jks
KS_PASS=ztlocalroot

[ -f "$AJAR" ] || { echo "缺少 android.jar: $AJAR"; exit 1; }
[ -f "$R8" ] || { echo "缺少 r8.jar: $R8"; exit 1; }

rm -rf "$BUILD"
mkdir -p "$BUILD/gen" "$BUILD/classes" "$BUILD/dex" "$OUT"

echo "[1/6] aapt2 compile"
aapt2 compile --dir "$APP/res" -o "$BUILD/res.zip"

echo "[2/6] aapt2 link"
aapt2 link -o "$BUILD/base.apk" -I "$AJAR" \
    --manifest "$APP/AndroidManifest.xml" \
    -A "$APP/assets" \
    --java "$BUILD/gen" \
    --min-sdk-version 26 --target-sdk-version 34 \
    "$BUILD/res.zip"

echo "[3/6] javac"
javac -encoding UTF-8 -source 8 -target 8 -Xlint:-options -nowarn \
    -classpath "$AJAR" -d "$BUILD/classes" \
    $(find "$APP/java" -name '*.java')

echo "[4/6] d8"
java -cp "$R8" com.android.tools.r8.D8 --release --min-api 26 \
    --lib "$AJAR" --output "$BUILD/dex" \
    $(find "$BUILD/classes" -name '*.class')

echo "[5/6] package"
cp "$BUILD/dex/classes.dex" "$BUILD/classes.dex"
mkdir -p "$BUILD/lib/arm64-v8a"
cp "$APP"/jniLibs/arm64-v8a/*.so "$BUILD/lib/arm64-v8a/"
( cd "$BUILD" && zip -q -X base.apk classes.dex && zip -q -X -r base.apk lib )

echo "[6/6] sign"
if [ ! -f "$KS" ]; then
    keytool -genkeypair -keystore "$KS" -alias zt -keyalg RSA -keysize 2048 \
        -validity 10000 -storepass "$KS_PASS" -keypass "$KS_PASS" \
        -dname "CN=ZT LocalRoot, O=ZT, C=CN" >/dev/null 2>&1
fi
zipalign -f 4 "$BUILD/base.apk" "$BUILD/aligned.apk"
apksigner sign --ks "$KS" --ks-pass "pass:$KS_PASS" --key-pass "pass:$KS_PASS" \
    --v1-signing-enabled true --v2-signing-enabled true \
    --out "$OUT/ZT-LocalRoot-v1.0.apk" "$BUILD/aligned.apk"

apksigner verify --print-certs "$OUT/ZT-LocalRoot-v1.0.apk" | head -5
ls -l "$OUT"
echo "OK -> $OUT/ZT-LocalRoot-v1.0.apk"
