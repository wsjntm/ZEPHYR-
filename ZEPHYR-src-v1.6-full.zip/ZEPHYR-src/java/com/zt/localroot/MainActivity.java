package com.zt.localroot;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import rikka.shizuku.Shizuku;
import rikka.shizuku.ShizukuProvider;

public class MainActivity extends Activity implements Engine.Ui {

    private boolean dark;
    private int BG, CARD, CARD2, TXT, DIM, ACCENT, BLUE, RED, YELLOW, BORDER, LOG_TXT, LOG_BG;

    /** 黑白主题：所有颜色都从这里取，切换后 recreate() 重建界面。 */
    private void loadTheme() {
        dark = prefs != null && "dark".equals(prefs.getString("theme", "light"));
        if (dark) {
            BG = 0xFF0D1117;
            CARD = 0xFF161B22;
            CARD2 = 0xFF1C232B;
            TXT = 0xFFE6EDF3;
            DIM = 0xFF8B949E;
            ACCENT = 0xFF3FB950;
            BLUE = 0xFF58A6FF;
            RED = 0xFFFF7B72;
            YELLOW = 0xFFD29922;
            BORDER = 0xFF30363D;
            LOG_TXT = 0xFFC9D1D9;
            LOG_BG = 0xFF0B0E13;
        } else {
            BG = 0xFFF3F5F8;
            CARD = 0xFFFFFFFF;
            CARD2 = 0xFFEDF1F5;
            TXT = 0xFF1B1F24;
            DIM = 0xFF6B7280;
            ACCENT = 0xFF0FA968;
            BLUE = 0xFF1668D9;
            RED = 0xFFD32F2F;
            YELLOW = 0xFF9A6A00;
            BORDER = 0xFFDDE3EA;
            LOG_TXT = 0xFF30363D;
            LOG_BG = 0xFFFBFCFE;
        }
    }

    private void applySystemBars() {
        try {
            getWindow().setStatusBarColor(BG);
            getWindow().setNavigationBarColor(BG);
            android.view.View dv = getWindow().getDecorView();
            int flags = dv.getSystemUiVisibility();
            if (dark) {
                flags &= ~android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                flags &= ~android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            } else {
                flags |= android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                flags |= android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
            dv.setSystemUiVisibility(flags);
        } catch (Throwable ignored) {
        }
    }

    private static final int REQ_SHIZUKU = 1001;
    private static final String SHIZUKU_PKG = "moe.shizuku.privileged.api";
    public static final String VER = "OS6-v1.6";

    private static final String[] MANAGER_PKGS = {
            "me.weishu.kernelsu", "com.resukisu.resukisu", "com.sukisu.ultra",
            "me.yuki.fina", "com.rifsxd.ksunext"
    };

    private static String managerName(String pkg) {
        if ("me.weishu.kernelsu".equals(pkg)) return "KernelSU";
        if ("com.resukisu.resukisu".equals(pkg)) return "BakaSU / ReSukiSU";
        if ("com.sukisu.ultra".equals(pkg)) return "SukiSU Ultra";
        if ("me.yuki.fina".equals(pkg)) return "FinaSU";
        if ("com.rifsxd.ksunext".equals(pkg)) return "KSU-Next";
        return pkg;
    }

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService pool = Executors.newSingleThreadExecutor();

    private Engine engine;
    private TextView statusView;
    private TextView shizukuView;
    private TextView logView;
    private TextView rootOut;
    private ScrollView logScroll;
    private EditText etCmd;
    private Button btnRun;
    private Button btnGrant;
    private final SpannableStringBuilder logBuf = new SpannableStringBuilder();
    private final StringBuilder fileBuf = new StringBuilder();
    private volatile boolean flusherOn;
    private volatile boolean dumpedPrev;
    private int flushCount;
    private volatile String appLogPath = "/data/local/tmp/zt-app.log";
    private PowerManager.WakeLock wakeLock;
    private NotificationManager nm;
    private SharedPreferences prefs;
    private boolean autoResumed;
    private volatile boolean running;
    private static final String CH_ID = "zt_status";
    private static final int NOTI_ID = 2001;
    private static final int REQ_NOTI = 1002;

    private final Shizuku.OnBinderReceivedListener binderReceived = new Shizuku.OnBinderReceivedListener() {
        public void onBinderReceived() {
            log("[i] Shizuku binder 已连接", Engine.L_CMD);
            refreshShizuku();
        }
    };

    private final Shizuku.OnBinderDeadListener binderDead = new Shizuku.OnBinderDeadListener() {
        public void onBinderDead() {
            log("[!] Shizuku binder 断开（服务退出或设备重启）", Engine.L_WARN);
            refreshShizuku();
        }
    };

    private final Shizuku.OnRequestPermissionResultListener permResult = new Shizuku.OnRequestPermissionResultListener() {
        public void onRequestPermissionResult(int requestCode, int grantResult) {
            boolean ok = grantResult == PackageManager.PERMISSION_GRANTED;
            log(ok ? "[✓] Shizuku 授权成功" : "[X] Shizuku 授权被拒绝", ok ? Engine.L_OK : Engine.L_ERR);
            refreshShizuku();
        }
    };

    // ------------------------------------------------------------------ setup

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        try {
            prefs = getSharedPreferences("zt", MODE_PRIVATE);
            loadTheme();
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "zt:run");
            wakeLock.setReferenceCounted(false);
            buildUi();
            applySystemBars();
            showFirstRunNotice();
            initNotifications();
            registerShizuku();
            log("[i] v" + VER + " · " + android.os.Build.MODEL + " / Android "
                    + android.os.Build.VERSION.RELEASE + " / " + android.os.Build.SUPPORTED_ABIS[0], Engine.L_CMD);
            refreshShizuku();
        } catch (Throwable t) {
            showFatal(t);
        }
    }

    /** 首次打开（安装后第一次）弹一次须知，3 秒后自动消失。 */
    private void showFirstRunNotice() {
        if (prefs == null || prefs.getBoolean("first_notice", false)) {
            return;
        }
        prefs.edit().putBoolean("first_notice", true).apply();
        final android.app.AlertDialog dlg = new android.app.AlertDialog.Builder(this)
                .setTitle("使用须知")
                .setMessage("本提权软件只适配骁龙处理器的 6.6.127-7741 内核，其它均不支持；管理器仅支持 KernelSU。")
                .setPositiveButton("知道了", null)
                .create();
        dlg.setOnShowListener(new android.content.DialogInterface.OnShowListener() {
            public void onShow(android.content.DialogInterface d) {
                ui.postDelayed(new Runnable() {
                    public void run() {
                        try {
                            if (dlg.isShowing()) {
                                dlg.dismiss();
                            }
                        } catch (Throwable ignored) {
                        }
                    }
                }, 3000);
            }
        });
        try {
            dlg.show();
        } catch (Throwable ignored) {
        }
    }

    private void registerShizuku() {
        try {
            Shizuku.addBinderReceivedListenerSticky(binderReceived);
            Shizuku.addBinderDeadListener(binderDead);
            Shizuku.addRequestPermissionResultListener(permResult);
        } catch (Throwable t) {
            log("[!] 注册 Shizuku 监听失败: " + t, Engine.L_WARN);
        }
        try {
            ShizukuProvider.requestBinderForNonProviderProcess(this);
        } catch (Throwable ignored) {
        }
    }

    /** 启动失败时把异常直接画在屏幕上，方便截图反馈。 */
    private void showFatal(Throwable t) {
        try {
            StringWriter sw = new StringWriter();
            t.printStackTrace(new PrintWriter(sw));
            TextView tv = new TextView(this);
            tv.setText("启动失败（v" + VER + "）\n\n" + sw.toString()
                    + "\n\n把这段文字发给开发者即可定位。");
            tv.setTextColor(0xFFFFB4B4);
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            tv.setTypeface(Typeface.MONOSPACE);
            tv.setTextIsSelectable(true);
            tv.setPadding(24, 60, 24, 24);
            ScrollView sv = new ScrollView(this);
            sv.setBackgroundColor(0xFF160B0B);
            sv.addView(tv);
            setContentView(sv);
        } catch (Throwable ignored) {
            Toast.makeText(this, "启动失败: " + t, Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshShizuku();
    }

    @Override
    protected void onDestroy() {
        if (engine != null) {
            engine.cancel();
        }
        try {
            Shizuku.removeRequestPermissionResultListener(permResult);
            Shizuku.removeBinderReceivedListener(binderReceived);
            Shizuku.removeBinderDeadListener(binderDead);
        } catch (Throwable ignored) {
        }
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
        }
        pool.shutdownNow();
        super.onDestroy();
    }

    // ------------------------------------------------------------------- ui

    private int dp(float v) {
        return (int) (getResources().getDisplayMetrics().density * v + 0.5f);
    }

    private TextView label(String text, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) {
            t.setTypeface(Typeface.DEFAULT_BOLD);
        }
        return t;
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD);
        g.setCornerRadius(dp(12));
        l.setBackground(g);
        l.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        l.setLayoutParams(lp);
        return l;
    }

    private TextView title(String s) {
        TextView t = label(s, 13, BLUE, true);
        t.setPadding(0, 0, 0, dp(6));
        return t;
    }

    private Button btn(String text, int fill, int textColor, final Runnable r) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        b.setTextColor(textColor);
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(9));
        b.setBackground(g);
        b.setPadding(dp(12), dp(6), dp(12), dp(6));
        b.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (r != null) {
                    r.run();
                }
            }
        });
        return b;
    }

    private EditText input(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(DIM);
        e.setTextColor(TXT);
        e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        e.setSingleLine(true);
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD2);
        g.setCornerRadius(dp(8));
        e.setBackground(g);
        e.setPadding(dp(10), dp(8), dp(10), dp(8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        e.setLayoutParams(lp);
        return e;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(8);
        l.setLayoutParams(lp);
        return l;
    }

    private void buildUi() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.setFillViewport(true);
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(18), dp(16), dp(28));
        sv.addView(c, new ScrollView.LayoutParams(ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));
        setContentView(sv);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView h = label("橘子6 · 临时 Root", 20, TXT, true);
        head.addView(h, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        Button gear = btn("⚙", CARD, TXT, new Runnable() {
            public void run() {
                openSettings();
            }
        });
        gear.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        GradientDrawable gg = new GradientDrawable();
        gg.setColor(CARD);
        gg.setCornerRadius(dp(22));
        gg.setStroke(dp(1), BORDER);
        gear.setBackground(gg);
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(dp(44), dp(44));
        head.addView(gear, glp);
        c.addView(head);

        TextView idView = label("酷安：w97114514", 12, BLUE, true);
        idView.setPadding(0, 0, 0, dp(8));
        idView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                copyText("w97114514");
                toast("已复制酷安 ID");
            }
        });
        c.addView(idView);
        statusView = label("状态：初始化…", 12, DIM, false);
        c.addView(statusView);


        // ① 一键提权（放最前面，确保一定看得见）
        LinearLayout s1 = card();
        s1.addView(title("① 一键提权"));
        btnRun = btn("▶ 开始一键提权", ACCENT, 0xFF04140C, new Runnable() {
            public void run() {
                doRun();
            }
        });
        btnRun.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(54));
        blp.topMargin = dp(4);
        btnRun.setLayoutParams(blp);
        s1.addView(btnRun);
        LinearLayout r1 = row();
        r1.addView(btn("自检", CARD2, TXT, new Runnable() {
            public void run() {
                doSelfTest();
            }
        }));
        r1.addView(btn("清理设备端", CARD2, TXT, new Runnable() {
            public void run() {
                doCleanup();
            }
        }));
        r1.addView(btn("复制日志", CARD2, TXT, new Runnable() {
            public void run() {
                copyLog();
            }
        }));
        s1.addView(r1);
        LinearLayout r1b = row();
        r1b.addView(btn("打开管理器", CARD2, TXT, new Runnable() {
            public void run() {
                openManager();
            }
        }));
        View padb0 = new View(this);
        padb0.setLayoutParams(new LinearLayout.LayoutParams(dp(8), 1));
        r1b.addView(padb0);
        r1b.addView(btn("切换管理器", CARD2, TXT, new Runnable() {
            public void run() {
                switchManager();
            }
        }));
        View padb = new View(this);
        padb.setLayoutParams(new LinearLayout.LayoutParams(dp(8), 1));
        r1b.addView(padb);

        s1.addView(r1b);
        c.addView(s1);

        // ② Shizuku
        LinearLayout s2 = card();
        s2.addView(title("② Shizuku 授权"));
        shizukuView = label("检测中…", 12, DIM, false);
        shizukuView.setPadding(0, 0, 0, dp(4));
        s2.addView(shizukuView);
        s2.addView(label("先打开 Shizuku 启动服务，再回这里点『授权』。", 11, DIM, false));
        LinearLayout r2 = row();
        r2.addView(btn("打开 Shizuku", CARD2, TXT, new Runnable() {
            public void run() {
                openShizuku();
            }
        }));
        btnGrant = btn("授权", ACCENT, 0xFF04140C, new Runnable() {
            public void run() {
                requestShizuku();
            }
        });
        r2.addView(btnGrant);
        r2.addView(btn("刷新", CARD2, TXT, new Runnable() {
            public void run() {
                refreshShizuku();
            }
        }));
        s2.addView(r2);
        c.addView(s2);

        // 日志
        logView = new TextView(this);
        logView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        logView.setTextColor(LOG_TXT);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setTextIsSelectable(true);
        logScroll = new ScrollView(this);
        GradientDrawable lg = new GradientDrawable();
        lg.setColor(LOG_BG);
        lg.setCornerRadius(dp(10));
        logScroll.setBackground(lg);
        logScroll.setPadding(dp(10), dp(10), dp(10), dp(10));
        logScroll.addView(logView);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(250));
        llp.topMargin = dp(10);
        logScroll.setLayoutParams(llp);
        c.addView(logScroll);

        // root 控制台
        LinearLayout s3 = card();
        s3.addView(title("③ root 控制台（成功后可用）"));
        LinearLayout r3 = row();
        etCmd = input("要执行的命令，例如 id");
        r3.addView(etCmd);
        View pad = new View(this);
        pad.setLayoutParams(new LinearLayout.LayoutParams(dp(8), 1));
        r3.addView(pad);
        r3.addView(btn("执行", BLUE, 0xFFFFFFFF, new Runnable() {
            public void run() {
                doRootCmd();
            }
        }));
        s3.addView(r3);
        rootOut = new TextView(this);
        rootOut.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        rootOut.setTypeface(Typeface.MONOSPACE);
        rootOut.setTextColor(LOG_TXT);
        rootOut.setTextIsSelectable(true);
        s3.addView(rootOut);
        c.addView(s3);
    }

    // --------------------------------------------------------------- logging

    private int colorFor(int level) {
        switch (level) {
            case Engine.L_OK:
                return ACCENT;
            case Engine.L_WARN:
                return YELLOW;
            case Engine.L_ERR:
                return RED;
            case Engine.L_CMD:
                return DIM;
            case Engine.L_HDR:
                return BLUE;
            default:
                return LOG_TXT;
        }
    }

    private void appendLog(String s, int level) {
        if (logView == null) {
            return;
        }
        int start = logBuf.length();
        logBuf.append(s).append("\n");
        logBuf.setSpan(new ForegroundColorSpan(colorFor(level)), start, logBuf.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (logBuf.length() > 200000) {
            logBuf.delete(0, 80000);
        }
        logView.setText(logBuf);
        appendFile(s);
        logScroll.post(new Runnable() {
            public void run() {
                logScroll.fullScroll(View.FOCUS_DOWN);
            }
        });
    }

    public void log(final String s, final int level) {
        ui.post(new Runnable() {
            public void run() {
                appendLog(s, level);
            }
        });
    }

    public void stage(final String s) {
        ui.post(new Runnable() {
            public void run() {
                if (statusView != null) {
                    statusView.setText("状态：" + s);
                }
                if (running) {
                    notifyStatus("一键Root · 进行中", s, true);
                }
            }
        });
    }

    public void progress(final int round, final int max) {
        ui.post(new Runnable() {
            public void run() {
                if (statusView != null) {
                    statusView.setText("状态：第 " + round + "/" + max + " 轮");
                }
                notifyStatus("一键Root · 执行中", "第 " + round + "/" + max + " 轮", true);
            }
        });
    }

    public void finished(final boolean ok, final String msg) {
        ui.post(new Runnable() {
            public void run() {
                if (statusView != null) {
                    statusView.setText("状态：" + (ok ? "完成 · " : "失败 · ") + msg);
                }
                running = false;
                try {
                    getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                } catch (Throwable ignored) {
                }
                if (prefs != null) {
                    prefs.edit().putBoolean("running", false).apply();
                    if (ok) {
                        prefs.edit().putInt("wins", prefs.getInt("wins", 0) + 1).apply();
                    }
                }
                notifyStatus(ok ? "一键Root · 完成" : "一键Root · 失败", msg, false);
                if (btnRun != null) {
                    btnRun.setEnabled(true);
                    btnRun.setText("▶ 开始一键提权");
                }
                if (wakeLock != null && wakeLock.isHeld()) {
                    wakeLock.release();
                }
                toast(ok ? "完成：" + msg : "失败：" + msg);
            }
        });
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private void copyLog() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("zt-log", logBuf.toString()));
        toast("日志已复制");
    }

    // ------------------------------------------------------------- shizuku

    private void refreshShizuku() {
        final boolean alive = ShizukuShell.alive();
        final boolean perm = alive && ShizukuShell.hasPermission();
        final int uid = alive ? ShizukuShell.serverUid() : -1;
        final String d = ShizukuShell.describe();
        ui.post(new Runnable() {
            public void run() {
                if (shizukuView != null) {
                    shizukuView.setText(d);
                    shizukuView.setTextColor(perm ? (uid == 0 ? ACCENT : BLUE) : (alive ? YELLOW : RED));
                }
                if (btnGrant != null) {
                    btnGrant.setEnabled(alive && !perm);
                    btnGrant.setText(perm ? "已授权" : "授权");
                }
                if (statusView != null) {
                    statusView.setText(!alive ? "状态：Shizuku 未连接" : (!perm ? "状态：等待 Shizuku 授权" : "状态：就绪"));
                }
                if (perm) {
                    pool.execute(new Runnable() {
                        public void run() {
                            dumpPreviousRun();
                        }
                    });
                }
            }
        });
    }

    private void openShizuku() {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(SHIZUKU_PKG);
            if (i == null) {
                toast("没装 Shizuku");
                return;
            }
            startActivity(i);
        } catch (Throwable t) {
            toast("打不开 Shizuku: " + t);
        }
    }

    private void requestShizuku() {
        try {
            if (!ShizukuShell.alive()) {
                try {
                    ShizukuProvider.requestBinderForNonProviderProcess(this);
                } catch (Throwable ignored) {
                }
                toast("Shizuku 服务未运行：先打开 Shizuku 启动服务");
                refreshShizuku();
                return;
            }
            if (ShizukuShell.hasPermission()) {
                toast("已经授权了");
                refreshShizuku();
                return;
            }
            ShizukuShell.requestPermission(REQ_SHIZUKU);
        } catch (Throwable t) {
            log("[X] 请求授权失败: " + t, Engine.L_ERR);
        }
    }

    // ------------------------------------------------------------ 日志落盘

    /** 每行都进缓冲，后台线程每秒追加写 /sdcard/zt-app.log（重启不丢）。 */
    private void appendFile(String s) {
        synchronized (fileBuf) {
            fileBuf.append(s).append('\n');
        }
        if (!flusherOn) {
            flusherOn = true;
            Thread t = new Thread(new Runnable() {
                public void run() {
                    while (true) {
                        try {
                            Thread.sleep(30000);
                        } catch (InterruptedException e) {
                            return;
                        }
                        flushFile();
                    }
                }
            });
            t.setDaemon(true);
            t.start();
        }
    }

    private volatile boolean holdDiskLog;

    public void holdDiskLog(boolean on) {
        holdDiskLog = on;
        if (!on) {
            flushFile();
        }
    }

    private void flushFile() {
        if (holdDiskLog) {
            return;
        }
        String data;
        synchronized (fileBuf) {
            if (fileBuf.length() == 0) {
                return;
            }
            data = fileBuf.toString();
            fileBuf.setLength(0);
        }
        if (!ShizukuShell.alive() || !ShizukuShell.hasPermission()) {
            synchronized (fileBuf) {
                fileBuf.insert(0, data);
            }
            return;
        }
        try {
            Process p = ShizukuShell.start("cat >> " + appLogPath);
            OutputStream os = p.getOutputStream();
            os.write(data.getBytes("UTF-8"));
            os.close();
            p.waitFor();
            if ((++flushCount % 10) == 0) {
                ShizukuShell.run(8000, "cp -f " + appLogPath + " " + appLogPath.replace("/data/local/tmp/", "/sdcard/") + " 2>/dev/null");
            }
        } catch (Throwable t) {
            synchronized (fileBuf) {
                fileBuf.insert(0, data);
            }
        }
    }

    // ------------------------------------------------------------ 设置

    /** 设置弹窗里左侧「标签 + 值」的一行。 */
    private LinearLayout infoRow(String k, TextView v) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setPadding(0, dp(2), 0, dp(2));
        r.addView(label(k, 11, DIM, false),
                new LinearLayout.LayoutParams(dp(32), LinearLayout.LayoutParams.WRAP_CONTENT));
        r.addView(v, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        return r;
    }

    private CheckBox cb(String text) {
        CheckBox c = new CheckBox(this);
        c.setText(text);
        c.setTextColor(TXT);
        c.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        c.setPadding(0, 0, 0, 0);
        return c;
    }

    private void openSettings() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(CARD);
        root.setPadding(dp(20), dp(16), dp(20), dp(4));

        // ───── 顶部：版本/设备/内核/载荷  +  作者主页
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);

        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        top.addView(left, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView vVer = label("v" + VER, 12, TXT, false);
        TextView vDev = label(android.os.Build.MODEL + " · Android " + android.os.Build.VERSION.RELEASE, 11.5f, TXT, false);
        final TextView vKern = label("读取中…", 11.5f, DIM, false);
        final TextView vPay = label("校验中…", 10, DIM, false);
        vPay.setTypeface(Typeface.MONOSPACE);
        vPay.setLineSpacing(dp(1), 1f);
        left.addView(infoRow("版本", vVer));
        left.addView(infoRow("设备", vDev));
        left.addView(infoRow("内核", vKern));
        left.addView(infoRow("载荷", vPay));

        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        top.addView(right, new LinearLayout.LayoutParams(dp(96), LinearLayout.LayoutParams.WRAP_CONTENT));
        right.addView(label("作者主页", 12, TXT, true));
        TextView rKuan = label("酷安", 10, DIM, false);
        rKuan.setPadding(0, dp(7), 0, 0);
        right.addView(rKuan);
        TextView rId = label("@w97114514", 11.5f, BLUE, true);
        rId.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW,
                            android.net.Uri.parse("https://www.coolapk.com/u/38988452"));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                    toast("正在打开酷安主页");
                } catch (Throwable t) {
                    copyText("https://www.coolapk.com/u/38988452");
                    toast("没有浏览器，链接已复制");
                }
            }
        });
        right.addView(rId);
        TextView rTip = label("点击打开", 9, DIM, false);
        right.addView(rTip);
        root.addView(top);

        // ───── 分割线
        View line = new View(this);
        line.setBackgroundColor(BORDER);
        LinearLayout.LayoutParams lineLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(1));
        lineLp.topMargin = dp(16);
        lineLp.bottomMargin = dp(8);
        root.addView(line, lineLp);

        // ───── 2×2 开关
        final CheckBox cbDark = cb("深色主题");
        cbDark.setChecked(dark);
        final CheckBox cbKill = cb("首轮清后台");
        cbKill.setChecked(prefs == null || prefs.getBoolean("kill_all", true));
        final CheckBox cbTemp = cb("温度 >40℃ 警告");
        cbTemp.setChecked(prefs == null || prefs.getBoolean("temp_warn", true));
        final CheckBox cbScreen = cb("自动熄屏");
        cbScreen.setChecked(prefs != null && prefs.getBoolean("auto_screen_off", false));

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.addView(cbDark, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row1.addView(cbKill, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(row1);

        final CheckBox cbTurbo = cb("兼容模式");
        cbTurbo.setChecked(prefs != null && prefs.getBoolean("env_turbo", false));

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.addView(cbTemp, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row2.addView(cbScreen, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(row2);

        LinearLayout row3 = new LinearLayout(this);
        row3.setOrientation(LinearLayout.HORIZONTAL);
        row3.addView(cbTurbo, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(row3);

        TextView turboTip = label("兼容模式 = 7741 工具同款：KHDUMP + NEO11_DOUBLE_SPRAY + KHONESHOT", 9.5f, DIM, false);
        turboTip.setPadding(0, 0, 0, dp(2));
        root.addView(turboTip);

        android.content.DialogInterface.OnClickListener onOk = new android.content.DialogInterface.OnClickListener() {
            public void onClick(android.content.DialogInterface d, int w) {
                if (prefs != null) {
                    prefs.edit()
                            .putBoolean("auto_screen_off", cbScreen.isChecked())
                            .putBoolean("kill_all", cbKill.isChecked())
                            .putBoolean("temp_warn", cbTemp.isChecked())
                            .putString("theme", cbDark.isChecked() ? "dark" : "light")
                            .putBoolean("env_turbo", cbTurbo.isChecked())
                            .apply();
                    if (cbDark.isChecked() != dark) {
                        if (running) {
                            toast("运行中不能重建界面，请等本轮结束再切主题");
                            return;
                        }
                        toast("主题已切换");
                        recreate();
                        return;
                    }
                    toast("设置已保存");
                }
            }
        };

        new android.app.AlertDialog.Builder(this)
                .setTitle("设置")
                .setView(root)
                .setPositiveButton("保存", onOk)
                .setNeutralButton("更新日志", new android.content.DialogInterface.OnClickListener() {
                    public void onClick(android.content.DialogInterface d, int w) {
                        showChangelog();
                    }
                })
                .setNegativeButton("关闭", null)
                .show();

        pool.execute(new Runnable() {
            public void run() {
                final String kern = ShizukuShell.alive()
                        ? ShizukuShell.run(15000, "uname -r").trim() : "Shizuku 未连接";
                File dir = new File(getFilesDir(), "payload");
                int ok = 0;
                StringBuilder detail = new StringBuilder();
                for (String n : new String[]{"zt_run", "zt_su", "zt_fanout.zte", "zt_su.zte"}) {
                    File f = new File(dir, n);
                    if (f.exists()) {
                        ok++;
                        detail.append(n).append(" ").append(f.length()).append("B\n");
                    } else {
                        detail.append(n).append(" 缺失\n");
                    }
                }
                String dStr = detail.toString().trim();
                final String payText = dStr;
                final boolean payOk = ok == 4;
                ui.post(new Runnable() {
                    public void run() {
                        vKern.setText(kern.length() > 26 ? kern.substring(0, 26) + "…" : kern);
                        vKern.setTextColor(kern.contains("6.6.127") ? ACCENT : TXT);
                        vPay.setText(payText);
                        vPay.setTextColor(payOk ? ACCENT : RED);
                    }
                });
            }
        });
    }

    // ---------------------------------------------------------- 管理器跳转

    private String findManager() {
        PackageManager pm = getPackageManager();
        String prefer = prefs == null ? null : prefs.getString("manager_pkg", null);
        if (prefer != null) {
            try {
                if (pm.getLaunchIntentForPackage(prefer) != null) {
                    return prefer;
                }
            } catch (Throwable ignored) {
            }
        }
        for (String p : MANAGER_PKGS) {
            try {
                if (pm.getLaunchIntentForPackage(p) != null) {
                    return p;
                }
            } catch (Throwable ignored) {
            }
        }
        // 兜底：扫已安装应用（依赖 QUERY_ALL_PACKAGES），兼容各种 KSU 分支
        try {
            java.util.List<android.content.pm.PackageInfo> all = pm.getInstalledPackages(0);
            log("[i] 可见应用数: " + (all == null ? 0 : all.size()), Engine.L_CMD);
            if (all != null) {
                for (android.content.pm.PackageInfo pi : all) {
                    String n = pi.packageName.toLowerCase();
                    if (n.contains("kernelsu") || n.contains("resukisu") || n.contains("ksunext")
                            || n.contains("sukisu") || n.endsWith(".ksu")) {
                        if (pm.getLaunchIntentForPackage(pi.packageName) != null) {
                            return pi.packageName;
                        }
                    }
                }
            }
        } catch (Throwable t) {
            log("[!] 扫描应用列表失败: " + t, Engine.L_WARN);
        }
        return null;
    }

    /** 列出所有已装的 KSU 系管理器，让用户指定默认打开哪个。 */
    private void switchManager() {
        final PackageManager pm = getPackageManager();
        final java.util.List<String> pkgs = new java.util.ArrayList<String>();
        final java.util.List<String> names = new java.util.ArrayList<String>();
        for (String p : MANAGER_PKGS) {
            try {
                if (pm.getLaunchIntentForPackage(p) != null) {
                    pkgs.add(p);
                    names.add(managerName(p));
                }
            } catch (Throwable ignored) {
            }
        }
        if (pkgs.isEmpty()) {
            toast("没检测到已安装的 KSU 系管理器");
            log("[!] 切换管理器：一个都没找到（KernelSU / BakaSU / SukiSU / KSU-Next）", Engine.L_WARN);
            return;
        }
        String cur = prefs == null ? null : prefs.getString("manager_pkg", null);
        int checked = pkgs.indexOf(cur);
        final String[] arr = names.toArray(new String[0]);
        new android.app.AlertDialog.Builder(this)
                .setTitle("切换管理器")
                .setSingleChoiceItems(arr, checked, new android.content.DialogInterface.OnClickListener() {
                    public void onClick(android.content.DialogInterface d, int which) {
                        String pkg = pkgs.get(which);
                        if (prefs != null) {
                            prefs.edit().putString("manager_pkg", pkg).apply();
                        }
                        log("[i] 默认管理器已切换为 " + managerName(pkg) + "（" + pkg + "）", Engine.L_OK);
                        toast("已切换为 " + managerName(pkg));
                        d.dismiss();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private void openManager() {
        String pkg = findManager();
        if (pkg == null) {
            log("[!] 没找到 KernelSU / ReSukiSU / KSU-Next 管理器（APatch 不适用：它用 apd，不是 ksud）", Engine.L_WARN);
            toast("没装 root 管理器");
            return;
        }
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            log("[i] 已打开管理器: " + pkg, Engine.L_OK);
        } catch (Throwable t) {
            log("[X] 打开管理器失败: " + t, Engine.L_ERR);
        }
    }

    public void onRootReady() {
        final String pkg = findManager();
        if (pkg == null) {
            log("[!] root 已就绪，但没装 KernelSU 管理器；装好后点『打开 KernelSU 管理器』", Engine.L_WARN);
            return;
        }
        log("[i] root 已就绪；激活脚本会自动拉起 " + pkg + "（没弹出就点上面的『打开管理器』）", Engine.L_OK);
    }

    /** 上次运行（尤其是崩溃重启前）的 exploit 日志，从 ext4 读，不受 FUSE 影响。 */
    private void dumpPreviousRun() {
        if (dumpedPrev || !ShizukuShell.alive() || !ShizukuShell.hasPermission()) {
            return;
        }
        dumpedPrev = true;
        String newest = ShizukuShell.run(15000,
                "ls -t /data/local/tmp/zt-run-*.log 2>/dev/null | head -1").trim();
        if (newest.length() == 0) {
            newest = "/data/local/tmp/zt-run.log";
        }
        final String runLogPath = newest;
        String sz = ShizukuShell.run(15000, "stat -c %s '" + runLogPath + "' 2>/dev/null").trim();
        if (sz.length() == 0 || "0".equals(sz) || sz.contains("ERROR")) {
            return;
        }
        log("[i] 上次运行日志 " + runLogPath + "（" + sz + " 字节）尾部：", Engine.L_HDR);
        String tail = ShizukuShell.run(20000, "tail -n 60 '" + runLogPath + "' 2>/dev/null");
        for (String line : tail.split("\n")) {
            String t = line.trim();
            if (t.length() > 0) {
                log("    | " + t, Engine.L_NORM);
            }
        }
        ShizukuShell.run(15000, "cp -f '" + runLogPath + "' '"
                + runLogPath.replace("/data/local/tmp/", "/sdcard/") + "' 2>/dev/null");
    }


    private static final String CHANGELOG =
            "ZEPHYR提权 · 版本历程\n"
            + "OS6 / vivo 6.6.127 内核 / Shizuku 单机方案\n"
            + "\n"
            + "【OS6-v1.2】当前版本\n"
            + "  · 移除开发者选项检查（后续实测表明它并非必死条件）\n"
            + "  · 轮次上限 60 → 20\n"
            + "\n"
            + "【OS6-v1.1】\n"
            + "  · 首次打开弹出使用须知（3 秒自动关闭）\n"
            + "  · 启动时校验内核 build 号 abogki543627741\n"
            + "\n"
            + "【OS6-v4.6】\n"
            + "  · 新增「兼容模式」：KHDUMP + NEO11_DOUBLE_SPRAY + KHONESHOT\n"
            + "    与 7741 工具同款启动参数，双倍喷洒直击跨缓存阶段\n"
            + "  · 启动前检查开发者选项、内核 kernelsu 模块残留\n"
            + "  · 日志副本增加非 0 字节校验，杜绝「大小对内容全 0」\n"
            + "  · 轮次上限 20 → 60，新增跨开机战绩统计\n"
            + "  · 清后台后多等 25 秒，等内存回收压缩完成\n"
            + "  · 清理进程改用 killall -9 zt_run zt_su zt_kha\n"
            + "\n"
            + "【OS6-v4.4】\n"
            + "  · 新增内核 kernelsu 模块残留检查（late-load 后不重启会污染 slab）\n"
            + "  · EXIT=9 增加解释：payload 自适应重试用尽，主动退出并还原内核\n"
            + "\n"
            + "【OS6-v4.3】\n"
            + "  · 新增开发者选项检查（实测关闭时跨缓存阶段必卡死）\n"
            + "  · 静默期从 300 秒回退到 40 秒\n"
            + "\n"
            + "【OS6-v4.2】\n"
            + "  · 自检新增环境快照：ADBD / DEVOPT / TCPPORT / 开机时长\n"
            + "\n"
            + "【OS6-v4.1】\n"
            + "  · 静默 300 秒实验版（已回退）\n"
            + "\n"
            + "【OS6-v4】\n"
            + "  · 静默期禁止落盘，避免 cat 进程打扰内核竞态\n"
            + "  · 静默期改纯 Java 睡眠，一个 shell 都不起\n"
            + "\n"
            + "【OS6-v3】\n"
            + "  · 适配 FinaSU 管理器（me.yuki.fina）\n"
            + "  · 新增「更新日志」页面，移除冗余的导出日志按钮\n"
            + "  · 设置页新增作者主页入口，左右两栏排版\n"
            + "\n"
            + "【OS6-v2】\n"
            + "  · 适配 BakaSU / SukiSU 管理器\n"
            + "  · 兼容随机改名的 ksud：按 ELF 内容特征识别，不认文件名\n"
            + "  · 新增「切换管理器」，可指定默认管理器\n"
            + "  · 新增黑白主题自由切换（含状态栏 / 导航栏）\n"
            + "  · 包名定为 OS6.Root66127，软件名 ZEPHYR提权\n"
            + "  · 移除临时 root 状态检测（误报多）\n"
            + "\n"
            + "【OS6-v1】\n"
            + "  · 版本命名改为 OS6 系列\n"
            + "  · 颜色全部改为变量驱动，为双主题打底\n"
            + "\n"
            + "【v2.41】\n"
            + "  · 跨开机 boot_id 比对，能识别「上一轮是内核 panic 重启」\n"
            + "  · 新增跨开机累计轮次统计\n"
            + "\n"
            + "【v2.40】\n"
            + "  · root 校验改为逐行扫描 + 最多 8 次重试\n"
            + "  · 修掉「明明拿到 uid=0 却判失败」的误判\n"
            + "  · 不再自动把 SELinux 切回 Enforcing（会掐断 zt_su 通道）\n"
            + "\n"
            + "【v2.39】\n"
            + "  · App 日志落盘 1 秒 → 30 秒\n"
            + "  · 启动后静默改为纯 Java 睡眠\n"
            + "  · 开机自动把 tmp 里的完整日志补到 /sdcard\n"
            + "  · 实测 SLAB_BASELINE 从 861 降到 248\n"
            + "\n"
            + "【v2.38】\n"
            + "  · 轮询 25 秒并绑定 CPU0，避开 payload 使用的 1~7 号核\n"
            + "  · 每轮开跑前清后台\n"
            + "  · 深阶段停滞容忍 420 → 600 秒\n"
            + "\n"
            + "【v2.37】\n"
            + "  · 自适应延时：还在出东西就续 180 秒，最多续 3 次\n"
            + "  · MISS 止损 8 次 → 16 次\n"
            + "\n"
            + "【v2.36】\n"
            + "  · 停滞阈值 240 → 420 秒\n"
            + "  · 取消「到 STAGE0 就收工」，同一次开机最多连打 20 轮\n"
            + "\n"
            + "【v2.35】\n"
            + "  · 改用 zt_state 握手（PID / EXIT）判断存活\n"
            + "  · 修掉 pidof 误判造成的「启动后很快退出」误杀\n"
            + "\n"
            + "【v2.34】\n"
            + "  · 日志副本改 cat 逐字节拷贝，修掉「大小对但内容全 0」\n"
            + "  · 新增心跳与死锁检测，卡死自动收尾\n"
            + "  · 修掉版本号常量写死、一直显示 2.23 的问题\n"
            + "\n"
            + "【v2.33】\n"
            + "  · 修「zt_run 没有任何输出」：启动脚本按时间戳命名却按大小跳过推送\n"
            + "\n"
            + "【v2.32】\n"
            + "  · load1 只打印不再等待\n"
            + "  · 自动续跑：崩溃重启后能接上次进度\n"
            + "\n"
            + "【v2.31】\n"
            + "  · 温度采样只取 CPU/GPU 相关 zone，阈值 45℃\n"
            + "\n"
            + "【v2.30】\n"
            + "  · 尝试限核与 --no-bind（实测被 payload 自身覆盖，已撤销）\n"
            + "\n"
            + "【v2.28】\n"
            + "  · 日志改为时间戳命名，保留最近 10 份\n"
            + "\n"
            + "【v2.23】\n"
            + "  · 20+ 阶段识别，失败时打印「本轮到达阶段」\n"
            + "\n"
            + "【v2.x】\n"
            + "  · 载荷 sha256 逐个校验\n"
            + "  · 通知栏常驻状态\n"
            + "  · 日志落盘 + /sdcard 镜像\n"
            + "\n"
            + "【v2.0】\n"
            + "  · 改用 Shizuku 授权，摆脱电脑与无线调试配对\n"
            + "\n"
            + "【v1.0】\n"
            + "  · 内置 adb + 无线调试版（需配对，已弃用）\n"
            ;

    private void showChangelog() {
        TextView tv = new TextView(this);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        tv.setTextColor(TXT);
        tv.setTypeface(Typeface.MONOSPACE);
        tv.setText(CHANGELOG);
        tv.setLineSpacing(dp(3), 1f);
        tv.setTextIsSelectable(true);
        ScrollView sc = new ScrollView(this);
        sc.setBackgroundColor(CARD);
        sc.setPadding(dp(18), dp(12), dp(18), dp(8));
        sc.addView(tv);
        new android.app.AlertDialog.Builder(this)
                .setTitle("更新日志")
                .setView(sc)
                .setPositiveButton("知道了", null)
                .show();
    }

    // ------------------------------------------------------------ 通知栏

    private void initNotifications() {
        try {
            nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel ch = new NotificationChannel(CH_ID, "提权状态", NotificationManager.IMPORTANCE_LOW);
                ch.setShowBadge(false);
                ch.setSound(null, null);
                nm.createNotificationChannel(ch);
            }
            if (Build.VERSION.SDK_INT >= 33
                    && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, REQ_NOTI);
            }
        } catch (Throwable t) {
            log("[!] 通知初始化失败: " + t, Engine.L_WARN);
        }
        notifyStatus("一键Root · 待机", "Shizuku: " + ShizukuShell.describe(), false);
    }

    private void notifyStatus(String title, String text, boolean ongoing) {
        if (nm == null) {
            return;
        }
        try {
            Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    ? new Notification.Builder(this, CH_ID) : new Notification.Builder(this);
            b.setSmallIcon(android.R.drawable.stat_notify_sync);
            b.setContentTitle(title);
            b.setContentText(text == null ? "" : text);
            b.setOngoing(ongoing);
            b.setOnlyAlertOnce(true);
            b.setShowWhen(true);
            Intent i = new Intent(this, MainActivity.class);
            i.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            b.setContentIntent(PendingIntent.getActivity(this, 0, i,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
            nm.notify(NOTI_ID, b.build());
        } catch (Throwable ignored) {
        }
    }

    private void copyText(String s) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("zt", s));
    }

    // ---------------------------------------------------------------- actions

    private void doRun() {
        if (engine != null) {
            engine.cancel();
        }
        if (!ShizukuShell.alive()) {
            toast("Shizuku 未运行：先打开 Shizuku 启动服务");
            requestShizuku();
            return;
        }
        if (!ShizukuShell.hasPermission()) {
            toast("先授权 Shizuku");
            requestShizuku();
            return;
        }
        running = true;
        try {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } catch (Throwable ignored) {
        }
        boolean resuming = prefs != null && prefs.getBoolean("running", false);
        btnRun.setEnabled(false);
        btnRun.setText(resuming ? "继续中…（看下面日志）" : "执行中…（看下面日志）");
        notifyStatus("一键Root · 开始", resuming ? "接上次进度…" : "正在准备…", true);
        if (wakeLock != null && !wakeLock.isHeld()) {
            wakeLock.acquire(60 * 60 * 1000L);
        }
        if (!resuming) {
            final String stamp = new java.text.SimpleDateFormat("MMdd-HHmm", java.util.Locale.US).format(new java.util.Date());
            appLogPath = "/data/local/tmp/zt-app-" + stamp + ".log";
            pool.execute(new Runnable() {
                public void run() {
                    appendFile("===== 新一次运行 " + stamp + " =====");
                }
            });
        }
        engine = new Engine(this, this);
        if (resuming) {
            engine.resume();
        } else {
            if (prefs != null) {
                prefs.edit().putBoolean("running", true).apply();
            }
            engine.start();
        }
    }

    /** 环境快照：adbd / 开发者选项 / 无线调试端口 / 开机时长。 */
    private void dumpEnv(StringBuilder sb) {
        String v = ShizukuShell.run(20000,
                "echo ADBD=$(getprop init.svc.adbd); "
                        + "echo DEVOPT=$(settings get global development_settings_enabled 2>/dev/null); "
                        + "echo TCPPORT=$(getprop service.adb.tcp.port); "
                        + "echo UPTIME=$(cat /proc/uptime | cut -d' ' -f1); "
                        + "echo ADBPROC=$(ps -A -o NAME 2>/dev/null | grep -c '^adbd$')");
        for (String line : v.split("\n")) {
            line = line.trim();
            if (line.startsWith("ADBD=") || line.startsWith("DEVOPT=")
                    || line.startsWith("TCPPORT=") || line.startsWith("ADBPROC=")) {
                sb.append("    ").append(line).append("\n");
            } else if (line.startsWith("UPTIME=")) {
                try {
                    long up = (long) Double.parseDouble(line.substring(7).trim());
                    sb.append("    开机 ").append(up / 60).append(" 分 ").append(up % 60).append(" 秒\n");
                } catch (Throwable ignored) {
                }
            }
        }
    }

    private void doSelfTest() {
        pool.execute(new Runnable() {
            public void run() {
                log("---------- 自检 v" + VER + " ----------", Engine.L_HDR);
                StringBuilder envSb = new StringBuilder();
                try {
                    dumpEnv(envSb);
                } catch (Throwable ignored) {
                }
                log("[0] 环境\n" + envSb, Engine.L_NORM);
                log("[1] Shizuku", Engine.L_HDR);
                log("    " + ShizukuShell.describe(), Engine.L_NORM);
                if (!ShizukuShell.alive()) {
                    log("    binder 未连接：请先打开 Shizuku 并启动服务", Engine.L_ERR);
                } else {
                    log("    version=" + ShizukuShell.serverVersion() + " uid=" + ShizukuShell.serverUid()
                            + " granted=" + ShizukuShell.hasPermission(), Engine.L_NORM);
                    String id = ShizukuShell.run(20000, "id");
                    log("    id: " + id.trim().replace("\n", " "), Engine.L_NORM);
                    String k = ShizukuShell.run(20000, "uname -r");
                    log("    内核: " + k.trim() + "（门禁 " + Engine.KERNEL_EXPECT + "）", Engine.L_NORM);
                    String t = ShizukuShell.run(20000, "ls -ld " + Engine.TMP);
                    log("    " + t.trim(), Engine.L_NORM);
                }
                log("[2] 内核模块 / vr 检测", Engine.L_HDR);
                String mods = ShizukuShell.run(20000, "cat /proc/modules 2>/dev/null | grep -iE 'vr|kernelsu|kpatch|vivo' | head -10");
                if (mods.trim().length() == 0) {
                    log("    /proc/modules 里没有 vr/kernelsu 相关模块", Engine.L_NORM);
                } else {
                    for (String l : mods.split("\n")) {
                        if (l.trim().length() > 0) log("    " + l.trim(), Engine.L_NORM);
                    }
                }
                String sysmod = ShizukuShell.run(20000, "ls /sys/module 2>/dev/null | grep -iE '^vr' | head -5");
                log("    /sys/module 里的 vr*: " + (sysmod.trim().length() == 0 ? "无" : sysmod.trim().replace("\n", " ")), Engine.L_NORM);
                String vrprop = ShizukuShell.run(20000, "getprop 2>/dev/null | grep -iE 'vr|antiroot' | head -5");
                if (vrprop.trim().length() > 0) {
                    for (String l : vrprop.split("\n")) {
                        if (l.trim().length() > 0) log("    " + l.trim(), Engine.L_CMD);
                    }
                }
                log("[3] 载荷校验", Engine.L_HDR);
                File dir = new Engine(MainActivity.this, MainActivity.this).preparePayload();
                if (dir == null) {
                    log("    [X] 载荷缺失或损坏", Engine.L_ERR);
                } else {
                    for (String n : new String[]{"zt_run", "zt_su", "zt_fanout.zte", "zt_su.zte"}) {
                        File f = new File(dir, n);
                        log("    " + n + "  " + f.length() + "B  " + Engine.sha256(f), Engine.L_NORM);
                    }
                }
            }
        });
    }

    private void doCleanup() {
        pool.execute(new Runnable() {
            public void run() {
                String cmd = "rm -f " + Engine.TMP + "/zt_run " + Engine.TMP + "/zt_su " + Engine.TMP
                        + "/zt_fanout.zte " + Engine.TMP + "/zt_su.zte " + Engine.TMP + "/zt_cmds.txt "
                        + Engine.TMP + "/zt_ksu.sh " + Engine.TMP + "/run.log; ls -l " + Engine.TMP + " 2>/dev/null";
                String out = ShizukuShell.run(40000, cmd);
                log("[*] 清理设备端残留", Engine.L_CMD);
                for (String l : out.split("\n")) {
                    if (l.trim().length() > 0) {
                        log("    " + l.trim(), Engine.L_NORM);
                    }
                }
            }
        });
    }

    private void doRootCmd() {
        final String c = etCmd.getText().toString().trim();
        if (c.length() == 0) {
            return;
        }
        pool.execute(new Runnable() {
            public void run() {
                String safe = c.replace("'", "'\\''");
                String out = ShizukuShell.run(60000, "printf '" + safe + "\\nexit\\n' | " + Engine.TMP + "/zt_su");
                final StringBuilder sb = new StringBuilder();
                for (String l : out.split("\n")) {
                    String s = l.trim();
                    if (s.length() > 0 && !s.contains("tty") && !s.contains("job control")) {
                        sb.append(s).append("\n");
                    }
                }
                if (sb.length() == 0) {
                    sb.append(out.trim()).append("\n");
                }
                final String text = sb.toString();
                ui.post(new Runnable() {
                    public void run() {
                        rootOut.setText(text);
                    }
                });
                log("[root] " + c + "\n" + text, Engine.L_OK);
            }
        });
    }
}
