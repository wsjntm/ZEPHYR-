package com.zt.localroot;

import android.content.pm.PackageManager;
import android.os.ParcelFileDescriptor;
import android.os.RemoteException;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import moe.shizuku.server.IRemoteProcess;
import moe.shizuku.server.IShizukuService;
import rikka.shizuku.Shizuku;

/**
 * 用 Shizuku 拿 shell(uid 2000) 进程，等价于原来的 adb shell。
 * 不再需要无线调试 / 配对 / adb 二进制。
 */
public class ShizukuShell {

    public static final String TMP = "/data/local/tmp";

    private static final String[] ENV = {
            "PATH=/sbin:/system/sbin:/system/bin:/system/xbin:/product/bin:/apex/com.android.runtime/bin",
            "HOME=" + TMP,
            "TMPDIR=" + TMP,
            "ANDROID_DATA=/data",
    };

    public static boolean alive() {
        try {
            return Shizuku.pingBinder();
        } catch (Throwable t) {
            return false;
        }
    }

    public static int serverUid() {
        try {
            return Shizuku.getUid();
        } catch (Throwable t) {
            return -1;
        }
    }

    public static int serverVersion() {
        try {
            return Shizuku.getVersion();
        } catch (Throwable t) {
            return -1;
        }
    }

    public static boolean hasPermission() {
        try {
            return Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    public static void requestPermission(int code) {
        Shizuku.requestPermission(code);
    }

    public static String describe() {
        if (!alive()) {
            return "Shizuku 未连接";
        }
        int uid = serverUid();
        String who = uid == 0 ? "root" : (uid == 2000 ? "shell" : ("uid=" + uid));
        if (!hasPermission()) {
            return "Shizuku 已连接(" + who + ")，未授权";
        }
        return "Shizuku 已授权(" + who + ")，v" + serverVersion();
    }

    private static IShizukuService service() throws RemoteException {
        IShizukuService s = IShizukuService.Stub.asInterface(Shizuku.getBinder());
        if (s == null) {
            throw new RemoteException("Shizuku binder 为空");
        }
        return s;
    }

    public static Process start(String[] cmd, String dir) throws RemoteException {
        IRemoteProcess rp = service().newProcess(cmd, ENV, dir == null ? TMP : dir);
        return new RemoteProcess(rp);
    }

    public static Process start(String cmd) throws RemoteException {
        return start(new String[]{"/system/bin/sh", "-c", cmd}, TMP);
    }

    /** 跑一条命令，返回 stdout+stderr（超时返回已读内容 + [TIMEOUT]）。 */
    public static String run(long timeoutMs, String cmd) {
        Process p;
        try {
            p = start(cmd);
        } catch (Throwable e) {
            return "ERROR: " + e.getMessage();
        }
        return drain(p, timeoutMs);
    }

    static String drain(Process p, long timeoutMs) {
        final ByteArrayOutputStream bos = new ByteArrayOutputStream();
        Thread t1 = reader(p.getInputStream(), bos);
        Thread t2 = reader(p.getErrorStream(), bos);
        long deadline = timeoutMs > 0 ? System.currentTimeMillis() + timeoutMs : 0;
        boolean timeout = false;
        while (true) {
            try {
                if (!p.isAlive()) {
                    break;
                }
            } catch (Throwable e) {
                break;
            }
            if (deadline > 0 && System.currentTimeMillis() > deadline) {
                timeout = true;
                break;
            }
            try {
                Thread.sleep(30);
            } catch (InterruptedException e) {
                break;
            }
        }
        if (timeout) {
            try {
                p.destroy();
            } catch (Throwable ignored) {
            }
        }
        try {
            t1.join(800);
            t2.join(800);
        } catch (InterruptedException ignored) {
        }
        synchronized (bos) {
            String s = new String(bos.toByteArray());
            return timeout ? s + "\n[TIMEOUT]" : s;
        }
    }

    private static Thread reader(final InputStream in, final ByteArrayOutputStream bos) {
        Thread t = new Thread(new Runnable() {
            public void run() {
                byte[] buf = new byte[8192];
                int n;
                try {
                    while ((n = in.read(buf)) > 0) {
                        synchronized (bos) {
                            if (bos.size() < 262144) {
                                bos.write(buf, 0, n);
                            }
                        }
                    }
                } catch (Throwable ignored) {
                }
            }
        });
        t.setDaemon(true);
        t.start();
        return t;
    }

    /** 把本地文件写进 /data/local/tmp（shell 身份 cat > 落盘），并 chmod。 */
    public static boolean push(File local, String remote, int mode, StringBuilder log) {
        Process p = null;
        try {
            p = start(new String[]{"/system/bin/sh", "-c", "cat > '" + remote + "'"}, TMP);
            OutputStream os = p.getOutputStream();
            InputStream in = new FileInputStream(local);
            byte[] buf = new byte[32768];
            int n;
            long total = 0;
            while ((n = in.read(buf)) > 0) {
                os.write(buf, 0, n);
                os.flush();
                total += n;
                if ((total & 0x3FFFF) < 32768) {
                    Thread.sleep(5);
                }
            }
            in.close();
            os.flush();
            os.close();
            long deadline = System.currentTimeMillis() + 180000;
            while (p.isAlive() && System.currentTimeMillis() < deadline) {
                Thread.sleep(50);
            }
            if (p.isAlive()) {
                p.destroy();
                if (log != null) {
                    log.append("push 超时: " + local.getName()).append('\n');
                }
                return false;
            }
        } catch (Throwable e) {
            if (log != null) {
                log.append("push 失败 " + local.getName() + ": " + e).append('\n');
            }
            return false;
        }
        String sz = run(20000, "wc -c < '" + remote + "' 2>/dev/null").trim();
        boolean ok = sz.equals(String.valueOf(local.length()));
        if (!ok && log != null) {
            log.append("大小不符 " + remote + " 期望 " + local.length() + " 实际 " + sz).append('\n');
            return false;
        }
        run(20000, "chmod " + mode + " '" + remote + "'");
        return true;
    }

    // ------------------------------------------------------------------ 进程封装

    static class RemoteProcess extends Process {
        private final IRemoteProcess rp;
        private final InputStream in;
        private final InputStream err;
        private final OutputStream out;

        RemoteProcess(IRemoteProcess rp) throws RemoteException {
            this.rp = rp;
            this.in = new ParcelFileDescriptor.AutoCloseInputStream(rp.getInputStream());
            this.err = new ParcelFileDescriptor.AutoCloseInputStream(rp.getErrorStream());
            this.out = new ParcelFileDescriptor.AutoCloseOutputStream(rp.getOutputStream());
        }

        @Override
        public OutputStream getOutputStream() {
            return out;
        }

        @Override
        public InputStream getInputStream() {
            return in;
        }

        @Override
        public InputStream getErrorStream() {
            return err;
        }

        @Override
        public int waitFor() {
            try {
                return rp.waitFor();
            } catch (Throwable e) {
                return -1;
            }
        }

        @Override
        public int exitValue() {
            try {
                return rp.exitValue();
            } catch (Throwable e) {
                return -1;
            }
        }

        @Override
        public void destroy() {
            try {
                rp.destroy();
            } catch (Throwable ignored) {
            }
        }

        @Override
        public boolean isAlive() {
            try {
                return rp.alive();
            } catch (Throwable e) {
                return false;
            }
        }
    }
}
