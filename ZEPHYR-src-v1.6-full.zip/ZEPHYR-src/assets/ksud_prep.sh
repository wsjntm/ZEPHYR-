#!/system/bin/sh
# 以 root 身份运行：把管理器的 base.apk 拷进 App 私有目录，供 Java 侧解压
PKG="$1"
DEST="$2"
U="$3"
APK=$(pm path "$PKG" 2>/dev/null | head -1 | sed 's/^package://')
if [ -z "$APK" ]; then
  APK=$(ls /data/app/*/"$PKG"-*/base.apk 2>/dev/null | head -1)
fi
if [ -z "$APK" ] || [ ! -f "$APK" ]; then
  echo "APK_MISS=$PKG"
  exit 3
fi
cp -f "$APK" "$DEST" 2>/dev/null || { echo "APK_CP_FAIL=$APK"; exit 4; }
chmod 644 "$DEST" 2>/dev/null
[ -n "$U" ] && chown "$U:$U" "$DEST" 2>/dev/null
echo "APK_OK=$APK"
