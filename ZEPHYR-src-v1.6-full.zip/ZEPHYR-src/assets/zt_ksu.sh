#!/system/bin/sh
# zt_ksu.sh — 必须由 root(uid=0) 执行（经 /data/local/tmp/zt_su）
# $1 = 用户在「切换管理器」里指定的包名（可空）
# 逻辑：逐个管理器找 ksud → late-load → 用 su -c id 验证 → 谁能起来就用谁
export PATH=/sbin:/system/sbin:/system/bin:/system/xbin

TMP=/data/local/tmp
LOG=$TMP/zt_ksu.log
ENF=/sys/fs/selinux/enforce
: > "$LOG"

KVER=$(uname -r | cut -d. -f1-2)
AVER=$(uname -r | grep -o 'android[0-9]*' | head -1)
KMI="${AVER}-${KVER}"

echo "[*] uid=$(id -u) uname=$(uname -r) kmi=$KMI" >> "$LOG"

# pm path 在 zt_su 的 root shell 里可能失败，失败就直接扫 /data/app
libdir_of() {
  D=$(pm path "$1" 2>/dev/null | head -1 | sed 's/^package://')
  if [ -n "$D" ] && [ -d "$(dirname "$D")/lib/arm64-v8a" ]; then
    echo "$(dirname "$D")/lib/arm64-v8a"
    return 0
  fi
  for d in /data/app/*/"$1"-*/lib/arm64-v8a; do
    [ -d "$d" ] && { echo "$d"; return 0; }
  done
  return 1
}

ksud_in() {
  L="$1"
  [ -d "$L" ] || return 1
  [ -f "$L/libksud.so" ] && { echo "$L/libksud.so"; return 0; }
  for f in "$L"/*.so; do
    [ -f "$f" ] || continue
    case "$(head -c 4 "$f" 2>/dev/null)" in
      *ELF*) ;;
      *) continue ;;
    esac
    if head -c 4000000 "$f" 2>/dev/null | grep -a -q -e "ksud::late_load" -e "ksud::metamodule" -e "kernelsu_patched_"; then
      echo "$f"
      return 0
    fi
  done
  return 1
}

su_ok() {
  su -c id 2>/dev/null | grep -q 'uid=0'
}

try_pkg() {
  P="$1"
  L=$(libdir_of "$P")
  K=""
  if [ -n "$L" ]; then K=$(ksud_in "$L"); fi
  if [ -z "$K" ] && [ -x "$TMP/ksud" ]; then K="$TMP/ksud"; fi
  if [ -z "$K" ]; then
    echo "[!] $P 拿不到 ksud（lib=${L:-无}）" >> "$LOG"
    return 1
  fi
  chmod 755 "$K" 2>/dev/null
  echo "[*] $P ksud=$K" >> "$LOG"

  # 不同管理器命令行不一样：
  #   KernelSU / BakaSU / KSU-Next : late-load --kmi --allow-shell --package-name
  #   SukiSU / FinaSU              : late-load --package-name（KMI 自动探测）
  for ARGS in \
      "late-load --kmi $KMI --allow-shell --package-name $P" \
      "late-load --package-name $P" \
      "late-load --post-magica --package-name $P" \
      "late-load --allow-shell --package-name $P"; do
    echo "  [try] $ARGS" >> "$LOG"
    "$K" $ARGS >> "$LOG" 2>&1
    RC=$?
    echo "LATE_LOAD_RC=$RC [$ARGS]"
    sleep 1
    if su_ok || grep -q kernelsu /proc/modules 2>/dev/null; then
      echo "PKG_OK=$P"
      echo "PKG_OK=$P args=[$ARGS]" >> "$LOG"
      echo "$P" > "$TMP/zt_ksu_pkg"
      return 0
    fi
  done
  echo "[!] $P 四种参数都没起来" >> "$LOG"
  return 1
}

DONE=0
PREF="$1"
if [ -n "$PREF" ] && try_pkg "$PREF"; then
  DONE=1
fi

if [ "$DONE" = "0" ]; then
  for P in me.weishu.kernelsu com.resukisu.resukisu com.sukisu.ultra me.yuki.fina com.rifsxd.ksunext; do
    try_pkg "$P" && { DONE=1; break; }
  done
fi

if grep -q kernelsu /proc/modules 2>/dev/null; then
  echo "KSU_MODULE=1"
else
  echo "KSU_MODULE=0"
fi

if [ "$DONE" = "1" ]; then
  echo 0 > "$ENF" 2>/dev/null
  for i in 1 2 3 4 5 6 7 8 9 10; do
    load_policy /sys/fs/selinux/policy >> "$LOG" 2>&1 && break
    sleep 2
  done
  echo 1 > "$ENF" 2>/dev/null
fi

PKG=$(cat "$TMP/zt_ksu_pkg" 2>/dev/null)
if [ -n "$PKG" ]; then
  ACT=$(cmd package resolve-activity --brief "$PKG" 2>/dev/null | tail -1)
  if [ -z "$ACT" ]; then
    ACT=$(dumpsys package "$PKG" 2>/dev/null | grep -m1 -A1 "android.intent.action.MAIN" | grep -o "$PKG/[^ ]*" | head -1)
  fi
  [ -n "$ACT" ] && am start -n "$ACT" >/dev/null 2>&1
fi
echo "DONE"
